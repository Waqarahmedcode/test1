declare module 'shell-quote' {
  export type ParsedToken = string | { op: string } | Record<string, unknown>;
  export function quote(args: readonly string[]): string;
  export function parse(command: string, env?: Record<string, string | undefined>): ParsedToken[];
}
