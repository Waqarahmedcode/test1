// Filters CLAUDE_CODE_* (and CLAUDECODE_*) unless explicitly preserved in
// ENV_PRESERVE. This is layer 2 of defense for #2357 (CLAUDE_CODE_EFFORT_LEVEL
// / CLAUDE_CODE_ALWAYS_ENABLE_EFFORT leaking into the SDK subprocess) — layer 1
// is BLOCKED_ENV_VARS in EnvManager.ts. Do NOT add the EFFORT_* vars to
// ENV_PRESERVE: preserving them would defeat the strip.
export const ENV_PREFIXES = ['CLAUDECODE_', 'CLAUDE_CODE_'];
export const ENV_EXACT_MATCHES = new Set([
  'CLAUDECODE',
  'CLAUDE_CODE_SESSION',
  'CLAUDE_CODE_ENTRYPOINT',
  'MCP_SESSION_ID',
]);

export const ENV_PROXY_VARS = new Set([
  'HTTP_PROXY',
  'HTTPS_PROXY',
  'ALL_PROXY',
  'NO_PROXY',
  'http_proxy',
  'https_proxy',
  'all_proxy',
  'no_proxy',
  'npm_config_proxy',
  'npm_config_https_proxy',
  'npm_config_noproxy',
  // Node's fetch ignores HTTP(S)_PROXY until this is set (NODE_USE_ENV_PROXY=1).
  // Claude Code applies it from user settings; the observer child does not
  // load those settings, so the flag has to travel with the other proxy vars
  // (#5400). The lowercase spelling matches the http_proxy family.
  'NODE_USE_ENV_PROXY',
  'node_use_env_proxy',
]);

export const ENV_PRESERVE = new Set([
  'CLAUDE_CODE_OAUTH_TOKEN',
  'CLAUDE_CODE_GIT_BASH_PATH',
  // The CLI documents CLAUDE_CODE_TMPDIR as the fix for a root-owned per-uid
  // /tmp/claude-<uid> directory (#4161). Stripping it here sent the SDK child
  // back to /tmp, so the child hit that directory and exited 1 on every spawn
  // — the user's only documented escape did nothing.
  'CLAUDE_CODE_TMPDIR',
  // Documented Claude Code gateway compatibility switch. The Observer must
  // inherit an explicit beta opt-out because settingSources: [] prevents the
  // SDK child from recovering it from user settings. Keep this as a single
  // named exception: arbitrary CLAUDE_CODE_* host settings remain stripped.
  'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS',
  // One of Claude Code's documented "no background updates" switches (the
  // other two, DISABLE_AUTOUPDATER and DISABLE_UPDATES, have no CLAUDE_CODE_
  // prefix and pass already). The worker's auto-update check reads it from its
  // own env to stay off (src/services/auto-update/auto-update-check.ts), and
  // every worker spawn passes through sanitizeEnv, so stripping it left the
  // updater running for a user who set it. The Observer's SDK child inherits
  // it too, which keeps the user's choice there as well. Keep this as a single
  // named exception: arbitrary CLAUDE_CODE_* host settings remain stripped.
  'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC',
  // claude-mem's own setting, not a CLI knob (the CLI never reads it): the
  // path to the claude binary, documented as settable from the file OR the
  // env. Every daemon spawn passes through sanitizeEnv, and the worker reads
  // the env override (SettingsDefaultsManager.applyEnvOverrides), so
  // stripping it silently dropped the env form.
  'CLAUDE_CODE_PATH',
  'CLAUDE_CODE_USE_BEDROCK',
  'CLAUDE_CODE_USE_VERTEX',
  'CLAUDE_CODE_USE_FOUNDRY',
  'CLAUDE_CODE_SKIP_BEDROCK_AUTH',
  'CLAUDE_CODE_SKIP_VERTEX_AUTH',
  'CLAUDE_CODE_SKIP_FOUNDRY_AUTH',
  'ANTHROPIC_BEDROCK_BASE_URL',
  'AWS_REGION',
  'AWS_PROFILE',
  'AWS_ACCESS_KEY_ID',
  'AWS_SECRET_ACCESS_KEY',
  'AWS_SESSION_TOKEN',
  'ANTHROPIC_VERTEX_PROJECT_ID',
  'CLOUD_ML_REGION',
  'GOOGLE_APPLICATION_CREDENTIALS',
  ...ENV_PROXY_VARS,
]);

export function sanitizeEnv(env: NodeJS.ProcessEnv = process.env): NodeJS.ProcessEnv {
  const sanitized: NodeJS.ProcessEnv = {};

  for (const [key, value] of Object.entries(env)) {
    if (value === undefined) continue;
    if (ENV_PRESERVE.has(key)) { sanitized[key] = value; continue; }
    if (ENV_EXACT_MATCHES.has(key)) continue;
    if (ENV_PREFIXES.some(prefix => key.startsWith(prefix))) continue;
    sanitized[key] = value;
  }

  return sanitized;
}
