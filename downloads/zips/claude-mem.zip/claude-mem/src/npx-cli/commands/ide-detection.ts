import { execFileSync } from 'child_process';
import { existsSync, readdirSync } from 'fs';
import { homedir } from 'os';
import { dirname, join } from 'path';
import { IS_WINDOWS } from '../utils/paths.js';
import { t3CodeSettingsPath } from '../../services/integrations/T3CodeInstaller.js';
import { kimiCodeHome } from '../../shared/kimi-paths.js';
import { getOpenCodeConfigDirectory } from '../../services/integrations/OpenCodeInstaller.js';
import { hermesHome } from '../../services/integrations/HermesInstaller.js';
import { devinConfigPath } from '../../services/integrations/DevinHooksInstaller.js';
import { getGooseConfigPath, getZedSettingsPath } from '../../services/integrations/McpIntegrations.js';
import { lookupWindowsCommandCandidates } from '../../shared/spawn.js';

export interface IDEInfo {
  id: string;
  label: string;
  detected: boolean;
  hint?: string;
}

export function initialIDESelection(ides: IDEInfo[]): string[] {
  const detected = ides.filter(ide => ide.detected).map(ide => ide.id);
  return detected.length ? detected : ['claude-code'];
}

function isCommandInPath(command: string): boolean {
  try {
    if (IS_WINDOWS) {
      // System32 where.exe with current-directory hits dropped: a planted
      // <command>.exe in the project dir must not count as an install.
      return lookupWindowsCommandCandidates(command).length > 0;
    } else {
      execFileSync('which', [command], { stdio: 'ignore' });
    }
    return true;
  } catch (error: unknown) {
    if (process.env.DEBUG) {
      console.error(`[ide-detection] ${command} not in PATH:`, error instanceof Error ? error.message : String(error));
    }
    return false;
  }
}

function hasVscodeExtension(extensionNameFragment: string): boolean {
  const extensionsDirectory = join(homedir(), '.vscode', 'extensions');
  if (!existsSync(extensionsDirectory)) return false;
  try {
    const entries = readdirSync(extensionsDirectory);
    return entries.some((entry) => entry.toLowerCase().includes(extensionNameFragment.toLowerCase()));
  } catch (error: unknown) {
    console.warn('[ide-detection] Failed to read VS Code extensions directory:', error instanceof Error ? error.message : String(error));
    return false;
  }
}

export function detectInstalledIDEs(): IDEInfo[] {
  const home = homedir();

  return [
    {
      id: 'claude-code',
      label: 'Claude Code',
      detected: isCommandInPath('claude'),
      hint: 'recommended',
    },
    {
      id: 'opencode',
      label: 'OpenCode',
      detected:
        existsSync(getOpenCodeConfigDirectory()) || isCommandInPath('opencode'),
      hint: 'plugin-based integration',
    },
    {
      id: 'openclaw',
      label: 'OpenClaw',
      detected: existsSync(join(home, '.openclaw')),
      hint: 'plugin-based integration',
    },
    {
      id: 'windsurf',
      label: 'Windsurf',
      detected: existsSync(join(home, '.codeium', 'windsurf')),
    },
    {
      id: 'codex-cli',
      label: 'Codex CLI',
      detected: existsSync(process.env.CODEX_HOME || join(home, '.codex')),
      hint: 'native hooks integration',
    },
    {
      id: 't3code',
      label: 'T3 Code',
      detected: existsSync(t3CodeSettingsPath()),
      hint: 'Codex + Claude native hooks and MCP',
    },
    {
      id: 'kimi',
      label: 'Kimi Code',
      detected: existsSync(kimiCodeHome()) || isCommandInPath('kimi'),
      hint: 'hooks + MCP integration',
    },
    {
      id: 'devin',
      label: 'Devin CLI / Desktop',
      detected: existsSync(devinConfigPath()) || isCommandInPath('devin'),
      hint: 'hooks integration',
    },
    {
      id: 'cursor',
      label: 'Cursor',
      detected: existsSync(join(home, '.cursor')),
      hint: 'hooks + MCP integration',
    },
    {
      id: 'grok-bot',
      label: 'Grok Bot',
      detected: existsSync(join(home, '.cursor')),
      hint: 'transcript watch + MCP integration',
    },
    {
      id: 'copilot-cli',
      label: 'Copilot CLI',
      detected: isCommandInPath('copilot'),
      hint: 'MCP-based integration',
    },
    {
      id: 'copilot-vscode',
      label: 'Copilot in VS Code',
      // Both entries share ~/.copilot, so only offer VS Code as detected when the CLI is not.
      detected: !isCommandInPath('copilot') && existsSync(process.env.COPILOT_HOME || join(home, '.copilot')),
      hint: 'MCP-based integration',
    },
    {
      id: 'antigravity',
      label: 'Antigravity',
      detected: existsSync(join(home, '.gemini', 'antigravity')) || isCommandInPath('agy'),
      hint: 'hooks + MCP integration',
    },
    {
      id: 'omp',
      label: 'OMP',
      detected: isCommandInPath('omp') || existsSync(join(home, '.omp')),
      hint: 'native hooks integration',
    },
    {
      id: 'hermes',
      label: 'Hermes Agent',
      detected: isCommandInPath('hermes') || existsSync(hermesHome()),
      hint: 'memory provider plugin + MCP search',
    },
    {
      id: 'pi',
      label: 'Pi',
      detected: isCommandInPath('pi') || existsSync(process.env.PI_CODING_AGENT_DIR || join(home, '.pi', 'agent')),
      hint: 'manual recall; check automatic capture compatibility',
    },
    {
      id: 'dsh',
      label: 'DeepSeek Harness',
      detected: isCommandInPath('dsh') || existsSync(process.env.DSH_HOME || join(home, '.dsh')),
      hint: 'native plugin + transcript capture',
    },
    {
      id: 'goose',
      label: 'Goose',
      detected:
        existsSync(dirname(getGooseConfigPath())) || isCommandInPath('goose'),
      hint: 'MCP-based integration',
    },
    {
      id: 'roo-code',
      label: 'Roo Code',
      detected: hasVscodeExtension('rooveterinaryinc.roo-cline'),
      hint: 'MCP-based integration',
    },
    {
      id: 'warp',
      label: 'Warp',
      detected: existsSync(join(home, '.warp')) || isCommandInPath('warp'),
      hint: 'MCP-based integration',
    },
    {
      id: 'zed',
      label: 'Zed',
      detected:
        existsSync(dirname(getZedSettingsPath())) || isCommandInPath('zed'),
      hint: 'MCP-based integration',
    },
  ];
}
