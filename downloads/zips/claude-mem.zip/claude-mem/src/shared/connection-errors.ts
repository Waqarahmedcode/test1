/**
 * The one "is this a refused connection?" check behind every worker-down
 * decision (HealthMonitor shutdown, installer shutdown, `npx claude-mem search`,
 * the OpenCode plugin).
 *
 * A refused connection surfaces differently per runtime, and a
 * `message.includes('ECONNREFUSED')` check misses most of them:
 * - Bun's fetch rejects with `code: 'ConnectionRefused'` and an
 *   "Unable to connect…" message that never mentions ECONNREFUSED.
 * - Node's undici rejects with `TypeError('fetch failed')`; the ECONNREFUSED
 *   code lives only on `error.cause`, and with happy-eyeballs on a nested
 *   AggregateError's `errors`.
 * - Some wrappers keep only Node's message text ("connect ECONNREFUSED …").
 *
 * No imports on purpose: this module is bundled into the hooks and the
 * OpenCode plugin.
 */

const CONNECTION_REFUSED_CODES: ReadonlySet<string> = new Set(['ECONNREFUSED', 'ConnectionRefused']);

function hasConnectionRefusedCode(error: unknown, seen: Set<unknown>): boolean {
  if (!error || typeof error !== 'object' || seen.has(error)) return false;
  seen.add(error);
  if (error instanceof Error && error.message.includes('ECONNREFUSED')) return true;
  const candidate = error as { code?: unknown; cause?: unknown; errors?: unknown };
  if (typeof candidate.code === 'string' && CONNECTION_REFUSED_CODES.has(candidate.code)) return true;
  if (hasConnectionRefusedCode(candidate.cause, seen)) return true;
  return Array.isArray(candidate.errors)
    && candidate.errors.some((nested) => hasConnectionRefusedCode(nested, seen));
}

/**
 * True when `error` (or anything on its `cause` / `errors` chain) is a refused
 * connection. Bun's "Unable to connect" text WITHOUT the ConnectionRefused code
 * is deliberately not a match: the same message covers other socket failures.
 */
export function isConnectionRefusedError(error: unknown): boolean {
  if (hasConnectionRefusedCode(error, new Set())) return true;
  return error instanceof Error && error.message.includes('ECONNREFUSED');
}

/**
 * Bind errors that no other process causes and no wait clears: EACCES (a
 * privileged port, or an address this user may not bind) and EADDRNOTAVAIL
 * (CLAUDE_MEM_WORKER_HOST is not an address of this machine). No worker can
 * ever listen there, so every launcher reports it as a boot failure with its
 * errno, never as a busy port or a duplicate worker.
 */
export function isUnbindablePortError(error: unknown): boolean {
  const code = (error as { code?: unknown } | null | undefined)?.code;
  return code === 'EACCES' || code === 'EADDRNOTAVAIL';
}

/** What fixes an unbindable worker port; every launcher's report names it. */
export const UNBINDABLE_PORT_REMEDIATION =
  'Set CLAUDE_MEM_WORKER_PORT to a port between 1024 and 65535 and CLAUDE_MEM_WORKER_HOST to an address of this machine (127.0.0.1 by default) in claude-mem settings';
