// SPDX-License-Identifier: Apache-2.0

/**
 * Endpoint presets for the `openai-compatible` provider.
 *
 * WHY THIS IS NOT JUST CLAUDE_MEM_OPENROUTER_BASE_URL. That setting already
 * turns the OpenRouter client into a generic OpenAI-compatible client, and it
 * is how people reach DeepSeek and LM Studio today. But it does so by riding
 * inside the OpenRouter provider, which carries three things that belong to
 * openrouter.ai and to the cmem.ai gateway specifically:
 *
 *   1. `HTTP-Referer` / `X-Title` attribution headers, which are sent to
 *      whatever host the base URL names. Pointing that at NVIDIA means
 *      claude-mem's OpenRouter leaderboard identity is announced to NVIDIA.
 *   2. `usage: { include: true }`, gated on the URL containing `openrouter.ai`
 *      — one special case that has to keep growing per endpoint.
 *   3. The cmem-gateway tuple locking in `resolveOpenRouterConfig`: a
 *      deliberately intricate set of rules about when a persisted base URL
 *      pins a persisted key, so an account-delivered gateway credential is
 *      never sent to a host the user just repointed. Every one of those rules
 *      is correct and none of them mean anything for a self-configured
 *      endpoint — but a user reaching NVIDIA still has to reason about them,
 *      because their config shares the same three settings keys.
 *
 * So a third-party endpoint gets its own provider id and its own settings,
 * built on the same `OpenAICompatibleProvider` scaffolding. Nothing about the
 * OpenRouter path changes, and `CLAUDE_MEM_OPENROUTER_BASE_URL` keeps working
 * for anyone already using it.
 *
 * A preset is only a default base URL plus a default model — everything a
 * preset sets can be overridden by the matching setting. `custom` (or an empty
 * preset) means "I will supply the base URL myself", which is the escape hatch
 * for any endpoint not listed here.
 */

export interface OpenAICompatPreset {
  id: string;
  /** Shown in the installer and the settings UI. */
  label: string;
  /** OpenAI-compatible base URL. Empty for `custom`. */
  baseUrl: string;
  /**
   * Model used when CLAUDE_MEM_OPENAI_COMPAT_MODEL is unset. Empty when there
   * is no sensible default (a local server serves whatever the user loaded).
   */
  defaultModel: string;
  /** False for local servers that accept any bearer token, or none. */
  requiresApiKey: boolean;
  /** One line for the installer/docs. */
  hint: string;
  /**
   * Header that carries the observed session's hashed id on every request,
   * for endpoints that route or cache per conversation.
   */
  sessionHeader?: string;
  /**
   * How this endpoint is asked to skip thinking, when it ignores the
   * OpenAI-compatible `reasoning: { enabled: false }` shape. Unset means that
   * shape.
   */
  reasoningOff?: OpenAICompatReasoningOff;
}

/**
 * How an endpoint is asked to skip thinking. `reasoning-disabled` is the
 * OpenAI-compatible shape; `effort-none` is an OpenAI `reasoning_effort`,
 * which some gateways honour when they ignore the former.
 */
export type OpenAICompatReasoningOff = 'reasoning-disabled' | 'effort-none';

export const OPENAI_COMPAT_PRESETS: readonly OpenAICompatPreset[] = [
  {
    id: 'nvidia-nim',
    label: 'NVIDIA NIM (build.nvidia.com)',
    baseUrl: 'https://integrate.api.nvidia.com/v1',
    // A small, fast model: observation extraction is a high-volume structured
    // task, not a reasoning benchmark. Override with any id from
    // build.nvidia.com — the value is passed verbatim.
    defaultModel: 'nvidia/nemotron-3.5-lightning-30b-a3b',
    requiresApiKey: true,
    hint: 'Free hosted inference across NVIDIA-served models. Key starts with nvapi- from build.nvidia.com.',
  },
  {
    id: 'orcarouter',
    label: 'OrcaRouter (orcarouter.ai)',
    baseUrl: 'https://api.orcarouter.ai/v1',
    defaultModel: 'openai/gpt-4o-mini',
    requiresApiKey: true,
    hint: 'One sk-orca- key for provider-scoped model ids such as anthropic/claude-haiku-4.5.',
  },
  {
    id: 'api-route',
    label: 'API Route (api-route.com)',
    baseUrl: 'https://global.api-route.com/v1',
    defaultModel: '',
    requiresApiKey: true,
    hint: 'API Route key; select a chat-completions model from your account catalog. Model ids are passed verbatim.',
  },
  {
    id: 'modelgo',
    label: 'ModelGo (modelgo.ai)',
    baseUrl: 'https://api.modelgo.ai/v1',
    // ModelGo keys expose the logical models enabled for that account. Do not
    // guess one here: users should choose a chat-completions model returned by
    // their authenticated GET /v1/models request.
    defaultModel: '',
    requiresApiKey: true,
    hint: 'mgk_ key from console.modelgo.ai; choose a logical chat-completions model returned by api.modelgo.ai/v1/models.',
  },
  {
    id: 'opper',
    label: 'Opper (opper.ai)',
    baseUrl: 'https://api.opper.ai/v3/compat',
    // A pooled model id: Opper picks the route per request. A small model for
    // the same reason as NVIDIA's default, extraction is high volume.
    defaultModel: 'gpt-5.4-mini',
    requiresApiKey: true,
    hint: 'EU-hosted gateway. One Opper key for pooled model ids such as claude-haiku-4-5; a provider/model id pins one route.',
  },
  {
    id: 'atlascloud',
    label: 'Atlas Cloud (atlascloud.ai)',
    baseUrl: 'https://api.atlascloud.ai/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek-ai/deepseek-v4-flash',
    requiresApiKey: true,
    hint: 'One Atlas Cloud key for vendor-prefixed model ids such as deepseek-ai/deepseek-v4-flash or zai-org/glm-5.3.',
  },
  {
    id: 'popnow',
    label: 'PopNow (popnow.ai)',
    baseUrl: 'https://api.popnow.ai/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids end in a task suffix and are passed verbatim.
    defaultModel: 'deepseek/v4-flash/chat',
    requiresApiKey: true,
    hint: 'One PopNow key for chat model ids such as deepseek/v4-flash/chat or moonshot/kimi-k3/chat.',
  },
  {
    id: 'runcrate',
    label: 'Runcrate (runcrate.ai)',
    baseUrl: 'https://api.runcrate.ai/v1',
    // A small, fast open model for the same reason as NVIDIA's default:
    // extraction is high volume. Ids are vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek-ai/DeepSeek-V4.1-Flash',
    requiresApiKey: true,
    hint: 'rc_live_ key from runcrate.ai; vendor-prefixed open model ids such as deepseek-ai/DeepSeek-V4.1-Flash or zai-org/GLM-5.3.',
  },
  {
    id: 'cheapaimodel',
    label: 'cheapaimodel (cheapaimodel.ai)',
    baseUrl: 'https://api.cheapaimodel.ai/v1',
    // A small, fast open model for the same reason as NVIDIA's default:
    // extraction is high volume. Ids are passed verbatim.
    defaultModel: 'deepseek-v4-1-flash',
    requiresApiKey: true,
    hint: 'Key from console.cheapaimodel.ai; open model ids such as deepseek-v4-1-flash or glm-5.3.',
  },
  {
    id: 'obscurify-ai',
    label: 'Obscurify.ai (obscurify.ai)',
    baseUrl: 'https://obscurify.ai/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek/deepseek-v4-flash',
    requiresApiKey: true,
    hint: 'sk-obs1_ key from obscurify.ai/account; vendor-prefixed model ids such as deepseek/deepseek-v4-flash or z-ai/glm-5.3. Obscurify says prompts and responses are not stored.',
  },
  {
    id: 'standardcompute',
    label: 'Standard Compute (standardcompute.com)',
    baseUrl: 'https://api.stdcmpt.com/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek/deepseek-v4-flash',
    requiresApiKey: true,
    hint: 'Key from standardcompute.com/dashboard/api-keys; vendor-prefixed model ids such as deepseek/deepseek-v4-flash or z-ai/glm-5.3. US endpoint: https://us.stdcmpt.com/v1.',
  },
  {
    id: 'uberllm',
    label: 'UberLLM (uberllm.dev)',
    baseUrl: 'https://api.uberllm.dev/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek/deepseek-v4.1-flash',
    requiresApiKey: true,
    hint: 'Key from uberllm.dev/dashboard/keys; vendor-prefixed model ids such as deepseek/deepseek-v4.1-flash or z-ai/glm-5.2, listed at api.uberllm.dev/v1/models.',
  },
  {
    id: 'hopbase',
    label: 'HopBase (hop-base.com)',
    baseUrl: 'https://api.hop-base.com/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are passed verbatim.
    defaultModel: 'deepseek-v4.1-flash',
    requiresApiKey: true,
    hint: 'Key from the HopBase console; model ids such as deepseek-v4.1-flash or claude-haiku-5-5, as listed by GET api.hop-base.com/v1/models for your key.',
  },
  {
    id: 'trustedrouter',
    label: 'TrustedRouter (trustedrouter.com)',
    baseUrl: 'https://api.trustedrouter.com/v1',
    // A cheap, fast fixed model for the same reason as NVIDIA's default:
    // extraction is high volume. trustedrouter/auto stays opt-in, since it
    // routes each request to a model priced up to frontier rates. Ids are
    // vendor-prefixed and passed verbatim.
    defaultModel: 'deepseek/deepseek-v4-flash',
    requiresApiKey: true,
    hint: 'Key from trustedrouter.com; vendor-prefixed model ids such as deepseek/deepseek-v4-flash, or trustedrouter/auto to route per request (priced per routed model), listed at api.trustedrouter.com/v1/models.',
  },
  {
    id: 'atmorouter',
    label: 'AtmoRouter (atmorouter.dev)',
    baseUrl: 'https://atmorouter.dev/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids carry a route prefix and are passed verbatim.
    defaultModel: 'zai/glm-5.3-flash',
    requiresApiKey: true,
    hint: 'Key (ar-...) from Dashboard > API Keys at atmorouter.dev; route-prefixed model ids such as zai/glm-5.3-flash or zai/glm-5.3, listed at atmorouter.dev/v1/models.',
  },
  {
    id: 'worldrouter',
    label: 'WorldRouter (worldrouter.ai)',
    baseUrl: 'https://inference-api.worldrouter.ai/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are unprefixed and passed verbatim.
    defaultModel: 'deepseek-v4-flash',
    requiresApiKey: true,
    hint: 'Key from worldrouter.ai; model ids such as deepseek-v4-flash or claude-haiku-5-5, listed at worldrouter.ai/models and by GET inference-api.worldrouter.ai/v1/models for your key.',
  },
  {
    id: 'aigrow',
    label: 'AIGROW (aigrow.gg)',
    baseUrl: 'https://aigrow.gg/v1',
    // A cheap, fast model for the same reason as NVIDIA's default: extraction
    // is high volume. Ids are unprefixed and passed verbatim.
    defaultModel: 'claude-haiku-5.5',
    requiresApiKey: true,
    hint: 'Key (ag_...) from aigrow.gg; model ids such as claude-haiku-5.5 or gemini-3.8-flash, listed with prices by GET aigrow.gg/v1/models, no key needed.',
  },
  {
    id: 'deepseek',
    label: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/v1',
    defaultModel: 'deepseek-chat',
    requiresApiKey: true,
    hint: 'Answers the case #2622 raised, without borrowing the OpenRouter settings keys.',
  },
  {
    id: 'opencode-go',
    label: 'OpenCode Go (opencode.ai)',
    baseUrl: 'https://opencode.ai/zen/go/v1',
    defaultModel: 'kimi-k3',
    requiresApiKey: true,
    hint: 'OpenCode Go subscription key; model ids from opencode.ai/zen/go/v1/models.',
    // Go answers 400 without it (#4581).
    sessionHeader: 'x-opencode-session',
    // Go ignores `reasoning: { enabled: false }` and keeps thinking; an OpenAI
    // `reasoning_effort` is the shape that turns it off there.
    reasoningOff: 'effort-none',
  },
  {
    id: 'opencode-zen',
    label: 'OpenCode Zen (opencode.ai)',
    baseUrl: 'https://opencode.ai/zen/v1',
    defaultModel: '',
    requiresApiKey: true,
    hint: 'Zen key. Only models Zen serves on /chat/completions work here.',
  },
  {
    id: 'groq',
    label: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: '',
    requiresApiKey: true,
    hint: 'Very fast; pick a model id from console.groq.com.',
  },
  {
    id: 'together',
    label: 'Together AI',
    baseUrl: 'https://api.together.xyz/v1',
    defaultModel: '',
    requiresApiKey: true,
    hint: 'Pick a model id from api.together.ai/models.',
  },
  {
    id: 'minimax',
    label: 'MiniMax (global)',
    baseUrl: 'https://api.minimax.io/v1',
    defaultModel: 'MiniMax-M3',
    requiresApiKey: true,
    hint: 'Key from platform.minimax.io; defaults to MiniMax-M3. Set MiniMax-M3.1-Flash (or any model id your account serves) to use Flash.',
  },
  {
    id: 'minimax-cn',
    label: 'MiniMax (China)',
    baseUrl: 'https://api.minimaxi.com/v1',
    defaultModel: 'MiniMax-M3',
    requiresApiKey: true,
    hint: 'Mainland-China accounts (platform.minimaxi.com).',
  },
  {
    id: 'iflytek',
    label: 'iFlytek Spark (Astron MaaS)',
    baseUrl: 'https://maas-api.cn-huabei-1.xf-yun.com/v2',
    defaultModel: 'spark-x2.5',
    requiresApiKey: true,
    hint: 'Pay-as-you-go MaaS key. Token Plan keys only work on https://maas-token-api.cn-huabei-1.xf-yun.com/v2.',
  },
  {
    id: 'ollama',
    label: 'Ollama (local)',
    baseUrl: 'http://localhost:11434/v1',
    defaultModel: '',
    requiresApiKey: false,
    hint: 'Local and free. Set the model to whatever `ollama list` shows.',
  },
  {
    id: 'lmstudio',
    label: 'LM Studio (local)',
    baseUrl: 'http://localhost:1234/v1',
    defaultModel: '',
    requiresApiKey: false,
    hint: 'Local and free. Ships no default model, so nothing is auto-loaded that the user did not ask for (#2393).',
  },
  {
    id: 'vllm',
    label: 'vLLM (self-hosted)',
    baseUrl: 'http://localhost:8000/v1',
    defaultModel: '',
    requiresApiKey: false,
    hint: 'Self-hosted OpenAI-compatible server.',
  },
  {
    id: 'custom',
    label: 'Custom OpenAI-compatible endpoint',
    baseUrl: '',
    defaultModel: '',
    requiresApiKey: false,
    hint: 'Set CLAUDE_MEM_OPENAI_COMPAT_BASE_URL and _MODEL by hand.',
  },
] as const;

export const DEFAULT_OPENAI_COMPAT_PRESET_ID = 'custom';

/**
 * Look up a preset by id. An unknown or empty id resolves to `custom` rather
 * than throwing: a typo in settings.json should degrade to "configure it by
 * hand", which then fails with a message naming the base URL, not to a crash
 * on a settings read that happens during status polling.
 */
export function resolveOpenAICompatPreset(id: unknown): OpenAICompatPreset {
  const wanted = typeof id === 'string' ? id.trim().toLowerCase() : '';
  if (!wanted) return getPreset(DEFAULT_OPENAI_COMPAT_PRESET_ID);
  return OPENAI_COMPAT_PRESETS.find(preset => preset.id === wanted)
    ?? getPreset(DEFAULT_OPENAI_COMPAT_PRESET_ID);
}

function getPreset(id: string): OpenAICompatPreset {
  const preset = OPENAI_COMPAT_PRESETS.find(entry => entry.id === id);
  if (!preset) throw new Error(`Unknown openai-compatible preset "${id}"`);
  return preset;
}
