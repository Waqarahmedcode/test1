/**
 * Per-provider quota circuit breaker (#3634).
 *
 * When a provider reports the user's inference allowance exhausted, nothing
 * stopped the worker from trying again: the generator exits, and the very next
 * captured tool call runs `ensureGeneratorRunning`, which starts a fresh
 * generator, sends one more request, and earns the same refusal. There is one
 * doomed request per observation, for the rest of the billing cycle — 11 capped
 * users produced tens of thousands of cap events in a single day, roughly a
 * hundred per successful observation.
 *
 * `ensureGeneratorRunning` already has exactly this gate for a missing Claude
 * CLI (`setup_required` + `CLAUDE_CLI_SETUP_RECHECK_COOLDOWN_MS`). This is the
 * same shape for quota, kept separate because quota is per-provider user state
 * rather than a machine-wide dependency.
 *
 * The breaker arms on a quota-exhausted generator exit, expires after a
 * cooldown so a single request can re-probe, and clears immediately on success
 * — so recovery costs at most one cooldown window, not a manual restart.
 *
 * PERSISTENCE, and the deliberate split within it.
 *
 * The armed window is written to disk beside `observer-health.json`, for the
 * reason that file's own docblock already gives: the state must survive worker
 * restarts. An in-memory-only breaker is cleared by every restart — the
 * `/api/admin/restart` endpoint (the process serving it IS the process holding
 * the Map), `npx claude-mem restart`, a reboot, a plugin-version SIGKILL, a
 * crash-and-respawn, and this repo's own documented `npm run build-and-sync`.
 * A crash-restart loop is the worst shape: crash, respawn, empty breaker,
 * doomed request, repeat — the storm again with extra steps.
 *
 * The probe claim (`probeInFlightSinceMs` / `probeClaimId`) is deliberately NOT
 * persisted, and must load as null. It is single-process concurrency state: a
 * restart kills every generator that could be holding one, so a claim restored
 * from disk would be owned by a dead process and would wedge the provider shut
 * until it went stale — the opposite of the failure this breaker prevents.
 */

import { existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'fs';
import { randomUUID } from 'crypto';
import { dirname, join } from 'path';
import { paths } from './paths.js';
import { logger } from '../utils/logger.js';
import { resolveConfigDirProfileKey } from './EnvManager.js';
import {
  clearObserverQuotaCooldown,
  recordObserverQuotaCooldown,
  type ObserverQuotaCooldown,
  type ObserverQuotaNoticeContext,
  type ObserverQuotaReason,
} from './observer-health.js';

export type QuotaProvider = 'claude' | 'gemini' | 'openrouter' | 'codex' | 'openai-compatible' | 'cmem-gateway';

/** The credential a Claude run billed: an ANTHROPIC_API_KEY, or the Claude Code login. */
export type ClaudeCredential = 'api-key' | 'subscription';

export const QUOTA_COOLDOWN_FILENAME = 'quota-cooldown.json';

/**
 * The persisted half of a breaker: the armed window only. Never the claim.
 */
interface PersistedQuotaCooldown {
  provider: QuotaProvider;
  message: string;
  window?: string;
  profile?: string;
  armedAtMs: number;
  cause?: 'auth';
  auth?: ClaudeCredential;
  reason?: ObserverQuotaReason;
}

/**
 * The 'cmem-gateway' entry only carries the single post-window re-probe claim
 * (tryAdmitCmemGatewayProbe). Its window is the fallback marker in
 * settings.json, which already survives restarts, and while it stands memory
 * runs on the Anthropic plan — nothing is paused. So it is never persisted
 * here, and never mirrored into observer-health as a cooldown.
 */
function isClaimOnly(state: QuotaCooldownState): boolean {
  return state.provider === 'cmem-gateway';
}

/**
 * The Claude account (config-dir profile) that 'claude' requests bill right
 * now. Quota is per account and CLAUDE_MEM_CLAUDE_CONFIG_DIR is re-read on
 * every spawn, so a 'claude' breaker belongs to the profile that armed it and
 * must not withhold requests from a different one.
 */
let resolveClaudeProfile: () => string = resolveConfigDirProfileKey;

export function setClaudeProfileResolverForTesting(resolver: (() => string) | null): void {
  resolveClaudeProfile = resolver ?? resolveConfigDirProfileKey;
}

/**
 * Whether a cooldown withholds requests from the account selected now. A
 * 'claude' cooldown, a spent allowance or a refused credential alike, belongs
 * to the config-dir profile its generator was spawned under, so it says
 * nothing about any other account, including one selected since (or a breaker
 * armed before they carried one). Other providers have one account.
 *
 * Every reader that decides whether requests wait goes through this one
 * predicate: admission (tryAdmitQuotaProbe), the resume sweep's pacing
 * (isQuotaCooldownActive, SessionRoutes.resumePendingSessions) and the
 * SessionStart pause notice, which reads the cooldown mirrored into
 * observer-health.json with its profile. A reader that skipped it held a
 * switched-to account's backlog behind the old account's breaker and told it
 * capture was paused.
 */
export function cooldownAppliesToCurrentAccount(cooldown: { provider: string; profile?: string }): boolean {
  return cooldown.provider !== 'claude' || cooldown.profile === resolveClaudeProfile();
}

function defaultCooldownFilePath(): string {
  return join(paths.dataDir(), QUOTA_COOLDOWN_FILENAME);
}

let hydrated = false;

/** Read the armed windows written by a previous process, once per process. */
function hydrateFromDisk(filePath: string = defaultCooldownFilePath()): void {
  if (hydrated) return;
  hydrated = true;
  try {
    if (!existsSync(filePath)) return;
    const parsed: unknown = JSON.parse(readFileSync(filePath, 'utf-8'));
    if (!Array.isArray(parsed)) return;
    for (const entry of parsed as PersistedQuotaCooldown[]) {
      if (!entry || typeof entry.provider !== 'string' || typeof entry.armedAtMs !== 'number') continue;
      cooldowns.set(entry.provider, {
        provider: entry.provider,
        message: entry.message ?? 'Provider reported the inference allowance exhausted',
        ...(entry.window ? { window: entry.window } : {}),
        ...(entry.profile ? { profile: entry.profile } : {}),
        ...(entry.cause === 'auth' ? { cause: 'auth' as const } : {}),
        ...(entry.auth === 'api-key' || entry.auth === 'subscription' ? { auth: entry.auth } : {}),
        ...(entry.reason ? { reason: entry.reason } : {}),
        armedAtMs: entry.armedAtMs,
        // Never restored: the process that could have held this is gone.
        probeInFlightSinceMs: null,
        probeClaimId: null,
      });
    }
    // The mirror on disk was written by whichever build armed these windows.
    // Each window's length is resolved by the current rule
    // (resolveQuotaCooldownMs), so restate the mirror from it once: a build
    // that held a rate limit for the quota cooldown left a half-hour `until`
    // behind that the breaker no longer honors.
    syncObserverHealthQuotaCooldown();
  } catch (err) {
    // A corrupt ledger must not stop the worker; it only costs one extra
    // request to re-arm the breaker.
    logger.warn('SESSION', 'Failed to read quota-cooldown file', { filePath }, err as Error);
  }
}

function persistToDisk(filePath: string = defaultCooldownFilePath()): void {
  try {
    mkdirSync(dirname(filePath), { recursive: true });
    const rows: PersistedQuotaCooldown[] = [...cooldowns.values()]
      .filter((state) => !isClaimOnly(state))
      .map((state) => ({
        provider: state.provider,
        message: state.message,
        ...(state.window ? { window: state.window } : {}),
        ...(state.profile ? { profile: state.profile } : {}),
        armedAtMs: state.armedAtMs,
        ...(state.cause ? { cause: state.cause } : {}),
        ...(state.auth ? { auth: state.auth } : {}),
        ...(state.reason ? { reason: state.reason } : {}),
      }));
    if (rows.length === 0) {
      if (existsSync(filePath)) unlinkSync(filePath);
      return;
    }
    const tmp = `${filePath}.${randomUUID()}.tmp`;
    try {
      writeFileSync(tmp, JSON.stringify(rows, null, 2), { encoding: 'utf-8', flag: 'wx' });
      // Atomic swap, so a reader never sees a half-written ledger.
      renameSync(tmp, filePath);
    } catch (error) {
      // A failed write or rename (Windows EPERM/EBUSY while the target is held)
      // would otherwise leave this randomly named temp behind on every attempt.
      try { unlinkSync(tmp); } catch { /* the temp may not exist */ }
      throw error;
    }
  } catch (err) {
    logger.warn('SESSION', 'Failed to write quota-cooldown file', { filePath }, err as Error);
  }
}

/**
 * How long to withhold requests after a provider reports the allowance spent.
 * Long enough that a capped user stops generating traffic, short enough that a
 * reset window (or a plan upgrade) is picked up without restarting the worker.
 */
export const QUOTA_EXHAUSTED_RECHECK_COOLDOWN_MS = 30 * 60_000;

/**
 * How long to withhold requests when the provider named a window that clears on
 * its own. A rate limit is a throttle, not a spent allowance, yet one that
 * outlasts its Retry-After resumes (or names no Retry-After) arms this same
 * breaker under the 'rate_limit' window (GeneratorRunner's
 * bookClassifiedFailure). Holding a throttle for the quota cooldown turns a
 * six-second refusal into a half-hour outage, and with a backlog already queued
 * every expiry buys the same refusal again — a window that cannot be waited
 * out. A limit that names a day or longer is a spent allowance and is
 * classified as one (quota_exhausted), so it keeps the full quota cooldown.
 */
export const RATE_LIMIT_RECHECK_COOLDOWN_MS = 90_000;

/**
 * Windows that come back without the billing period turning over. An unlisted
 * or absent window keeps the full quota cooldown, so an unfamiliar provider is
 * never treated as transient by accident.
 */
const TRANSIENT_QUOTA_WINDOWS = new Set([
  'rate_limit',
  // A provider that cannot serve right now (an outage that outlived its
  // retries, replies with no usable output), armed only while the fallback
  // takes the work (provider-dispatch's routeAroundUnservableProvider).
  'unavailable',
]);

/**
 * The cooldown an armed window is entitled to. Read from the window rather than
 * stored, so a window armed by an older build is resolved by the current rule.
 *
 * Deliberately takes no duration parameter: the whole point is that the window
 * is the only thing that decides, so a caller cannot reintroduce the mismatch
 * this replaced. Admission (`tryAdmitQuotaProbe`), the read-only check
 * (`isQuotaCooldownActive`) and the observer-health mirror all ask it; tests
 * that need to pin a duration pass one to `isQuotaCooldownActive` or
 * `syncObserverHealthQuotaCooldown`, where it overrides this.
 */
export function resolveQuotaCooldownMs(window: string | undefined): number {
  return window !== undefined && TRANSIENT_QUOTA_WINDOWS.has(window)
    ? RATE_LIMIT_RECHECK_COOLDOWN_MS
    : QUOTA_EXHAUSTED_RECHECK_COOLDOWN_MS;
}

/**
 * How long a claimed probe may stay unresolved before another caller may take
 * it. A generator that dies without reaching any completion path would
 * otherwise hold the claim forever and wedge the provider permanently — the
 * opposite failure to the one this breaker exists to prevent.
 */
export const QUOTA_PROBE_STALE_MS = 5 * 60_000;

export interface QuotaCooldownState {
  provider: QuotaProvider;
  /** Provider-reported reason, already free of any user prompt text. */
  message: string;
  /** Window the provider named, when it named one (e.g. 'weekly'). */
  window?: string;
  /** 'claude' only: the config-dir profile whose quota was exhausted. */
  profile?: string;
  armedAtMs: number;
  /**
   * 'auth' for a refused credential (recordAuthCooldown). It withholds requests
   * exactly like a spent allowance, but it is not a quota pause, so it is never
   * mirrored into observer-health as one; the health ledger's refused-credential
   * warning is what the user sees.
   */
  cause?: 'auth';
  /**
   * 'claude' only: the credential whose run spent its allowance (or was paused
   * by the quota guard). CLAUDE_MEM_QUOTA_FALLBACK_AUTH_METHOD names the other
   * credential to run on while this breaker holds (claudeQuotaStandIn). Absent
   * when a quota-fallback run was refused too: both are spent.
   */
  auth?: ClaudeCredential;
  /** Structured facts for the SessionStart notice, independent of log wording. */
  reason?: ObserverQuotaReason;
  /**
   * When the single post-expiry probe was claimed, or null when none is in
   * flight. Without this the expiry check is a bare read: every concurrent
   * session passes it at once and they all hit the provider together, which on
   * a busy machine (#3800 saw 28-69 live sessions) turns "one probe per window"
   * back into a burst.
   */
  probeInFlightSinceMs: number | null;
  /**
   * Identifies the claim currently in flight, so only the caller that took it
   * can release it. A generator admitted while no breaker existed holds no
   * claim at all; without this id its exit would clear whatever probe a later
   * session had since started, readmitting a third session while the real
   * probe is still running.
   */
  probeClaimId: number | null;
}

/**
 * The result of an admission attempt. `claimId` is null on an admission that
 * took no claim — there was no breaker to claim against — and releasing must be
 * keyed on it rather than on "I was admitted", because such a generator can
 * outlive a later session's real probe.
 */
export interface QuotaProbeAdmission {
  admitted: boolean;
  claimId: number | null;
}

const cooldowns = new Map<QuotaProvider, QuotaCooldownState>();

/**
 * Monotonic id for probe claims, only ever compared for equality. A claim's
 * timestamp cannot double as its identity: the testing seams admit repeat
 * claims inside a single millisecond, and two claims sharing an id would
 * reintroduce exactly the cross-session release this exists to prevent.
 */
let nextProbeClaimId = 1;

/** Arm the breaker for `provider`. Re-arming restamps the cooldown. */
export function recordQuotaExhausted(
  provider: QuotaProvider,
  message: string,
  window?: string,
  /**
   * When the window was armed. Defaults to now for a real refusal; passed
   * explicitly only when reviving a window that was armed before a restart,
   * so a reload cannot restamp it and hold the provider shut for a fresh full
   * cooldown on every restart.
   */
  armedAtMs: number = Date.now(),
  /**
   * 'claude' only: the account the refused generator was spawned under. A
   * late refusal from a generator started before an account switch belongs
   * to that account, not the one selected now. Defaults to the current one.
   */
  profile?: string,
  /** 'claude' only: the credential the refused generator billed (QuotaCooldownState.auth). */
  auth?: ClaudeCredential,
  reason?: ObserverQuotaReason,
): QuotaCooldownState {
  const noticeReason: ObserverQuotaReason = reason ?? (window === 'unavailable'
    ? { kind: 'unavailable' }
    : window === 'rate_limit'
      ? { kind: 'busy' }
      : provider === 'claude'
        ? auth === 'api-key' ? { kind: 'api_key_limit' } : { kind: 'used_up', ...(window ? { window } : {}) }
        : { kind: 'out_of_quota' });
  return armCooldown({ provider, message, ...(window ? { window } : {}), armedAtMs, profile, ...(auth ? { auth } : {}), reason: noticeReason });
}

/**
 * Withhold requests to `provider` after it refused the credential (a revoked
 * key, a bad key). Every request fails until the user acts, so this stops one
 * wasted request per captured event, with the same single re-probe per window.
 * `profile` is as for recordQuotaExhausted: 'claude' only, the spawn-time account.
 */
export function recordAuthCooldown(
  provider: QuotaProvider,
  message: string,
  profile?: string,
): QuotaCooldownState {
  return armCooldown({ provider, message, armedAtMs: Date.now(), profile, cause: 'auth' });
}

function armCooldown(
  armed: Pick<QuotaCooldownState, 'provider' | 'message' | 'window' | 'armedAtMs' | 'profile' | 'cause' | 'auth' | 'reason'>,
): QuotaCooldownState {
  hydrateFromDisk();
  const { profile, ...rest } = armed;
  const state: QuotaCooldownState = {
    ...rest,
    ...(armed.provider === 'claude' ? { profile: profile ?? resolveClaudeProfile() } : {}),
    // Re-arming ends whatever probe was in flight: this IS that probe failing.
    probeInFlightSinceMs: null,
    probeClaimId: null,
  };
  cooldowns.set(armed.provider, state);
  persistToDisk();
  syncObserverHealthQuotaCooldown();
  return state;
}

/** Clear the breaker — call on any successful generation for that provider. */
export function clearQuotaCooldown(provider: QuotaProvider): void {
  hydrateFromDisk();
  cooldowns.delete(provider);
  persistToDisk();
  syncObserverHealthQuotaCooldown();
}

export function getQuotaCooldown(provider: QuotaProvider): QuotaCooldownState | null {
  hydrateFromDisk();
  return cooldowns.get(provider) ?? null;
}

/**
 * True while requests to `provider` should be withheld from the account
 * selected now. Read-only — it never claims the probe, so it is safe for
 * logging and diagnostics.
 *
 * Callers deciding whether to actually send must use `tryAdmitQuotaProbe`
 * instead: this returning false only means the window elapsed, and on a machine
 * with many live sessions every one of them observes that at the same instant.
 */
export function isQuotaCooldownActive(
  provider: QuotaProvider,
  nowMs: number = Date.now(),
  cooldownMs?: number,
): boolean {
  hydrateFromDisk();
  const state = cooldowns.get(provider);
  if (!state || !cooldownAppliesToCurrentAccount(state)) return false;
  return nowMs - state.armedAtMs < (cooldownMs ?? resolveQuotaCooldownMs(state.window));
}

/**
 * True while dispatch should route AROUND `provider` (the quota fallback): the
 * account selected now is inside the provider's window
 * (resolveQuotaCooldownMs), or past it while the single post-window probe is
 * still in flight and not yet stale.
 *
 * The read-only twin of `tryAdmitQuotaProbe`: the same account check and the
 * same two conditions, but it never claims a probe or drops a breaker.
 * `isQuotaCooldownActive` reads the window alone, which would send every
 * session back to a provider whose one permitted probe is still running — the
 * herd this breaker exists to stop.
 */
export function isQuotaCooldownHolding(
  provider: QuotaProvider,
  nowMs: number = Date.now(),
): boolean {
  hydrateFromDisk();
  const state = cooldowns.get(provider);
  if (!state || !cooldownAppliesToCurrentAccount(state)) return false;
  if (nowMs - state.armedAtMs < resolveQuotaCooldownMs(state.window)) return true;
  const inFlight = state.probeInFlightSinceMs;
  return inFlight !== null && nowMs - inFlight < QUOTA_PROBE_STALE_MS;
}

/**
 * Decide whether this caller may send to `provider`, claiming the single
 * post-expiry probe if so.
 *
 * Admits when there is no breaker at all, or when the window has elapsed and no
 * probe is currently in flight. The claim is taken synchronously, so among
 * concurrent callers on this single-threaded worker exactly one wins and the
 * rest are withheld until that probe resolves — success clears the breaker,
 * failure re-arms it, and `releaseQuotaProbe` covers every other exit.
 *
 * An admission with no breaker in place carries a null `claimId`: it owns no
 * probe, and passing that null back to `releaseQuotaProbe` is what stops such a
 * generator from clearing a probe some later session claimed while it ran.
 */
export function tryAdmitQuotaProbe(
  provider: QuotaProvider,
  nowMs: number = Date.now(),
): QuotaProbeAdmission {
  // A breaker armed before a restart is still armed. Without this the first
  // call in a fresh process finds an empty Map, admits, and takes no claim —
  // the herd returns at exactly the moment the breaker should be strongest.
  hydrateFromDisk();
  let state = cooldowns.get(provider);
  // A breaker armed under another Claude account says nothing about the
  // account now selected: drop it and let this request through, instead of
  // pausing capture until that account resets. Switching back re-probes the
  // first account once; one request is cheaper than keeping a breaker per
  // account.
  if (state && !cooldownAppliesToCurrentAccount(state)) {
    clearQuotaCooldown(provider);
    state = undefined;
  }
  if (!state) return { admitted: true, claimId: null };

  if (nowMs - state.armedAtMs < resolveQuotaCooldownMs(state.window)) {
    return { admitted: false, claimId: null };
  }

  const inFlight = state.probeInFlightSinceMs;
  if (inFlight !== null && nowMs - inFlight < QUOTA_PROBE_STALE_MS) {
    return { admitted: false, claimId: null };
  }

  // A stale takeover mints a fresh id, so the abandoned owner's late release
  // finds a claim it does not own and leaves this one alone.
  const claimId = nextProbeClaimId++;
  state.probeInFlightSinceMs = nowMs;
  state.probeClaimId = claimId;
  return { admitted: true, claimId };
}

/**
 * Claim the cmem gateway's single post-window re-probe (provider-dispatch.ts)
 * with the same claim every breaker hands out: one holder at a time, a stale
 * takeover, and releases scoped to the claim id (`releaseQuotaProbe`).
 *
 * The gateway has no breaker window of its own — the fallback marker in
 * settings.json is its window, and the caller has already found it elapsed —
 * so its entry is armed at the epoch (always elapsed) and exists only for the
 * claim. It is created on first use, never persisted, and never mirrored as a
 * pause (isClaimOnly).
 */
export function tryAdmitCmemGatewayProbe(nowMs: number = Date.now()): QuotaProbeAdmission {
  hydrateFromDisk();
  if (!cooldowns.has('cmem-gateway')) {
    cooldowns.set('cmem-gateway', {
      provider: 'cmem-gateway',
      message: 'cmem.ai gateway re-probe',
      armedAtMs: 0,
      probeInFlightSinceMs: null,
      probeClaimId: null,
    });
  }
  return tryAdmitQuotaProbe('cmem-gateway', nowMs);
}

/**
 * Release the probe this run claimed, without deciding the breaker's fate.
 *
 * Called on every generator exit: if the probe succeeded the breaker is already
 * gone, and if it earned another refusal `recordQuotaExhausted` already re-armed
 * and cleared the claim. This covers the remaining exits (abort, crash, an
 * unrelated error) so a claim can never outlive the request that took it.
 *
 * `claimId` scopes that to the caller's own claim. Generators overlap freely —
 * one admitted before any breaker existed can exit long after a later session
 * claimed the sole post-cooldown probe — so an unscoped release would clear a
 * probe still in flight and admit a third session behind it.
 */
export function releaseQuotaProbe(provider: QuotaProvider, claimId: number | null): void {
  // Admitted with no breaker armed: this run never owned a probe, and any probe
  // in flight now belongs to a different session.
  if (claimId === null) return;
  hydrateFromDisk();

  const state = cooldowns.get(provider);
  if (state && state.probeClaimId === claimId) {
    state.probeInFlightSinceMs = null;
    state.probeClaimId = null;
  }
}

export function resetQuotaCooldownsForTesting(): void {
  cooldowns.clear();
  resolveClaudeProfile = resolveConfigDirProfileKey;
  // The latch must drop too, or a test that wrote a ledger would leak its
  // armed windows into the next test through a stale "already hydrated".
  hydrated = false;
  try {
    const filePath = defaultCooldownFilePath();
    if (existsSync(filePath)) unlinkSync(filePath);
  } catch {
    // Nothing to clean up.
  }
  try {
    clearObserverQuotaCooldown();
  } catch {
    // Observability must never affect the breaker, including test reset.
  }
}

/**
 * Where memory capture runs while `provider` is held — another provider that
 * dispatch is actually using and that is not itself held — or null.
 *
 * Injected rather than imported: the answer needs dispatch and the provider
 * credential checks, and provider-dispatch already imports this module, so
 * importing it back would be a cycle. provider-dispatch registers the real
 * answer when it loads; in any process that never loads it, this stays null
 * and the mirror carries no serving provider.
 */
export interface QuotaFallbackResolution {
  servingProvider: QuotaProvider | null;
  notice: ObserverQuotaNoticeContext;
}

export type QuotaFallbackResolver = (
  provider: QuotaProvider,
  nowMs: number,
  holds: readonly ObserverQuotaCooldown[],
) => QuotaProvider | QuotaFallbackResolution | null;

let quotaFallbackResolver: QuotaFallbackResolver | null = null;

/**
 * provider-dispatch's routeAroundUnservableProvider, for callers that cannot
 * import provider-dispatch: ResponseProcessor sits on the import path of the
 * very providers dispatch imports, so a direct import is a cycle that leaves
 * OpenRouterProvider's base class uninitialized. Registered when dispatch
 * loads; until then (a process that never loads it) nothing is routed.
 */
export type UnservableProviderRouter = (
  provider: QuotaProvider,
  message: string,
  window: 'unavailable' | 'rate_limit',
  profile?: string,
) => QuotaProvider | null;

let unservableProviderRouter: UnservableProviderRouter | null = null;

export function setUnservableProviderRouter(router: UnservableProviderRouter | null): void {
  unservableProviderRouter = router;
}

/** See UnservableProviderRouter. Null when dispatch is not loaded. */
export function routeAroundUnservableProviderIfLoaded(
  ...args: Parameters<UnservableProviderRouter>
): QuotaProvider | null {
  return unservableProviderRouter?.(...args) ?? null;
}

/** Install the resolver; returns the previous one so a caller can restore it. */
export function setQuotaFallbackResolver(resolver: QuotaFallbackResolver | null): QuotaFallbackResolver | null {
  const previous = quotaFallbackResolver;
  quotaFallbackResolver = resolver;
  return previous;
}

/**
 * Mirror the in-memory breaker into observer-health.json so session-start
 * and external monitors can see an intentional pause. Best-effort: a health
 * write failure must not change admission or drain-on-clear.
 *
 * Only a LIVE window is mirrored. An elapsed window withholds nothing right now
 * — `tryAdmitQuotaProbe` already admits the single recovery probe past it — so
 * reporting it `active: true` would keep the session-start banner up on a
 * cooldown that no longer holds, the exact stale-report failure
 * `observer-health.ts` warns about (`until` is authoritative). Skipping elapsed
 * entries here also stops a breaker for a provider the user stopped using from
 * resurfacing once the live entries clear.
 *
 * The elapsed entry is NOT removed from the map: it stays as admission state.
 * It gates the single post-cooldown recovery probe (`tryAdmitQuotaProbe` admits
 * one caller and withholds the rest) and a failed probe re-arms it in place;
 * deleting it would let `tryAdmitQuotaProbe` find no state and admit every
 * concurrent caller at once — the request burst the breaker exists to prevent.
 * It leaves the map only on a successful generation (`clearQuotaCooldown`).
 *
 * The legacy fields retain the longest hold for health API compatibility.
 * The notice also carries both roles' holds, so it can name the earliest retry
 * when neither provider can serve.
 *
 * When another provider is serving (a quota fallback), the mirror names it, so
 * the session-start notice says capture continues instead of saying it is
 * paused. The answer is recomputed on every arm and clear, and on a Codex
 * store, which clears no breaker of its own (ResponseProcessor's
 * releaseQuotaBreaker); between those events it can go stale (a settings edit,
 * a login change, a window elapsing into a probe).
 *
 * Tests pass a clock: the elapsed-window paths need one they control, which
 * the internal callers (always "now") cannot supply. `cooldownMs` pins one
 * duration for every window, for tests only.
 */
export function syncObserverHealthQuotaCooldown(
  nowMs: number = Date.now(),
  cooldownMs?: number,
): void {
  try {
    let latest: QuotaCooldownState | null = null;
    let latestUntil = 0;
    const holds: ObserverQuotaCooldown[] = [];
    for (const state of cooldowns.values()) {
      // Neither the gateway's claim holder nor a refused credential is a quota
      // pause to announce (see isClaimOnly and QuotaCooldownState.cause).
      if (isClaimOnly(state) || state.cause === 'auth') continue;
      const until = state.armedAtMs + (cooldownMs ?? resolveQuotaCooldownMs(state.window));
      if (until <= nowMs) continue;
      holds.push({
        active: true,
        provider: state.provider,
        ...(state.profile ? { profile: state.profile } : {}),
        armedAt: state.armedAtMs,
        until,
        ...(state.auth ? { auth: state.auth } : {}),
        ...(state.reason ? { reason: state.reason } : {}),
      });
      if (!latest || until > latestUntil) {
        latest = state;
        latestUntil = until;
      }
    }

    if (!latest) {
      clearObserverQuotaCooldown();
      return;
    }
    const resolution = quotaFallbackResolver?.(latest.provider, nowMs, holds) ?? null;
    const servingProvider = typeof resolution === 'object' && resolution !== null
      ? resolution.servingProvider : resolution;
    const notice = typeof resolution === 'object' && resolution !== null ? resolution.notice : undefined;
    recordObserverQuotaCooldown({
      active: true,
      provider: latest.provider,
      // The account it pauses: the SessionStart notice shows it only while
      // that account is selected (cooldownAppliesToCurrentAccount).
      ...(latest.profile ? { profile: latest.profile } : {}),
      armedAt: latest.armedAtMs,
      until: latestUntil,
      ...(latest.window ? { window: latest.window } : {}),
      ...(latest.auth ? { auth: latest.auth } : {}),
      ...(latest.reason ? { reason: latest.reason } : {}),
      message: latest.message,
      ...(servingProvider ? { servingProvider } : {}),
      ...(notice ? { notice } : {}),
    });
  } catch (err) {
    logger.warn('SESSION', 'Failed to mirror quota cooldown into observer-health', {}, err as Error);
  }
}
