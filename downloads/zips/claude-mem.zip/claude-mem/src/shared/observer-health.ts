// SPDX-License-Identifier: Apache-2.0

/**
 * File-backed observer pipeline health, so "observations are not flowing" is
 * never silent (the 2026-08-09 provider-quota outage ran 17 hours unnoticed).
 *
 * The worker records generator failures (SessionRoutes generator catch) and
 * successful stores (ResponseProcessor). Session-start context assembly
 * (ContextBuilder) reads the file and prepends a loud warning when the
 * observer is unhealthy. A file — not the in-memory dependency-health map —
 * because the state must survive worker restarts and be readable from any
 * process without the worker HTTP API (same pattern as the oauth-stale
 * marker in oauth-token.ts).
 */

import { existsSync, mkdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { paths } from './paths.js';
import { loadFromFileOnce } from './hook-settings.js';
import { viewerBaseUrl } from './viewer-url.js';
import { relayedLine, relayedLink } from './relayed-text.js';
import { logger } from '../utils/logger.js';
import { emitContextInvalidation } from './context-invalidation.js';
import { sleepSync } from './atomic-json.js';

export interface ObserverHealthState {
  /** Failures since the last successful store. */
  consecutiveFailures: number;
  /**
   * Epoch ms of the first failure since the kind last changed — the outage the
   * warning names. It is not "the first failure in the streak": a quota pause that
   * later becomes a refused credential is two outages, and dating the refusal
   * from the pause told one reader the credentials had been refused for three
   * days when the log showed an auth failure 21 hours old (#5378).
   */
  failingSinceAt: number | null;
  /** Epoch ms of the most recent failure. */
  lastErrorAt: number | null;
  /** Scrubbed + truncated message of the most recent failure. */
  lastErrorMessage: string | null;
  /** Provider whose generator failed most recently. */
  lastErrorProvider: string | null;
  /** Epoch ms of the most recent successful observation/summary store. */
  lastSuccessAt: number | null;
  /**
   * Structured detail from a classified provider error (the gateway's taxonomy
   * envelope `{ code, message, action, url, request_id }`), carried so the
   * session-start warning shows the same words as the worker's `Observer failed`
   * log line. All null for unclassified failures and for ledgers written by
   * older builds.
   */
  lastErrorCode?: string | null;
  /** Scrubbed remedy text ("It resets on …", "Add credits at …"). */
  lastErrorAction?: string | null;
  /** Link the remedy points at (stored as-is; URLs are not credentials). */
  lastErrorUrl?: string | null;
  /** Gateway/upstream request id for support. */
  lastErrorRequestId?: string | null;
  /**
   * Classified failure kind (`quota_exhausted`, `auth`, …). The warning reads
   * this to pick its remedy: a spent allowance is the one outage a restart
   * cannot clear, so it must not be offered one.
   */
  lastErrorKind?: string | null;
  /**
   * Intentional pause while the provider quota breaker is withholding
   * generator starts. Distinct from lastError*: a cooldown is not a failure,
   * and must not flip the ledger to unhealthy. Null when no breaker is armed
   * (or after it was cleared on a successful store).
   */
  quotaCooldown: ObserverQuotaCooldown | null;
}

/**
 * Persisted half of the quota breaker, mirrored into the health ledger so a
 * cooldown is visible without tailing the worker log. `until` is authoritative:
 * a stale `active: true` after expiry must not keep the banner up.
 */
export interface ObserverQuotaCooldown {
  active: boolean;
  provider: string;
  /**
   * 'claude' only: the config-dir profile (Claude account) the breaker pauses.
   * A reader shows the pause only while that account is selected
   * (quota-cooldown's cooldownAppliesToCurrentAccount).
   */
  profile?: string;
  /** Epoch ms when the breaker was armed. */
  armedAt: number;
  /** Epoch ms when the next probe is allowed. */
  until: number;
  /** Window the provider named, when it named one (e.g. 'weekly'). */
  window?: string;
  /** Provider-reported reason, already free of any user prompt text. */
  message?: string;
  /**
   * Where memory capture runs while this provider is held: the configured
   * quota fallback, or the recovered primary when the fallback's own breaker
   * is the one mirrored. Absent when no fallback is configured or nothing
   * else can serve; the notice then says capture is paused.
   */
  servingProvider?: string;
  /** 'claude' only: the credential that is held ('api-key' | 'subscription'), when one is. */
  auth?: string;
  /** Facts recorded when the hold was booked, independent of its log message. */
  reason?: ObserverQuotaReason;
  /** Worker-resolved roles and names; absent in ledgers written by older builds. */
  notice?: ObserverQuotaNoticeContext;
}

export type ObserverQuotaReason =
  | { kind: 'limit_guard'; window: string; usagePercent: number; thresholdPercent: number; resetsAt?: number }
  | { kind: 'reset_buffer_guard'; window: string; usagePercent: number; resetsAt: number }
  | { kind: 'used_up'; window?: string; resetsAt?: number }
  | { kind: 'api_key_limit' }
  | { kind: 'out_of_quota' | 'unavailable' | 'busy' | 'unknown' };

export interface ObserverQuotaNoticeHold {
  provider: string;
  /** 'claude' only: the account the hold pauses (cooldownAppliesToCurrentAccount). */
  profile?: string;
  displayName: string;
  retryName: string;
  role: 'main' | 'backup';
  until: number;
  auth?: string;
  reason?: ObserverQuotaReason;
}

export interface ObserverQuotaNoticeContext {
  mainProvider: string;
  mainDisplayName: string;
  mainRetryName: string;
  backupProvider?: string;
  backupDisplayName?: string;
  defaultClaudeBackup: boolean;
  servingProvider?: string;
  servingDisplayName?: string;
  servingAuth?: string;
  holds: ObserverQuotaNoticeHold[];
}

/**
 * Failure detail accepted by recordObserverFailure. A plain string is the
 * legacy/unclassified form; the object form carries the classified error's
 * structured fields.
 */
export interface ObserverFailureDetail {
  message: string;
  /** Classified error kind, when the failure came from the provider taxonomy. */
  kind?: string;
  code?: string;
  action?: string;
  url?: string;
  requestId?: string;
}

export const OBSERVER_HEALTH_FILENAME = 'observer-health.json';

/** Warn only after repeated failures — a single blip self-heals on retry. */
export const OBSERVER_UNHEALTHY_FAILURE_THRESHOLD = 3;

const MAX_ERROR_MESSAGE_LENGTH = 600;

const EMPTY_STATE: ObserverHealthState = {
  consecutiveFailures: 0,
  failingSinceAt: null,
  lastErrorAt: null,
  lastErrorMessage: null,
  lastErrorProvider: null,
  lastSuccessAt: null,
  lastErrorCode: null,
  lastErrorAction: null,
  lastErrorUrl: null,
  lastErrorRequestId: null,
  quotaCooldown: null,
};

function defaultHealthFilePath(): string {
  return join(paths.dataDir(), OBSERVER_HEALTH_FILENAME);
}

/**
 * Names that carry a secret when they appear as `name=value`, `name: value`,
 * or `"name": "value"` — the shapes provider errors echo back from request
 * bodies, query strings, and header dumps.
 */
const CREDENTIAL_ASSIGNMENT_PATTERN =
  /(["']?\b(?:api[_-]?key|apikey|access[_-]?token|auth[_-]?token|refresh[_-]?token|id[_-]?token|session[_-]?token|client[_-]?secret|secret[_-]?key|secret|password|passwd|pwd|authorization|auth|token|key)\b["']?\s*[=:]\s*)(["']?)([^\s"'&,;}\]]+)\2/gi;

/**
 * Keep the message useful (provider errors often embed the remedy, e.g. an
 * OpenRouter manage-key URL) while dropping anything credential-shaped.
 *
 * Applied before persistence AND again at render time, so a ledger written by
 * an older build cannot inject a secret into session-start context.
 */
export function scrubErrorMessage(message: string): string {
  return message
    .replace(/\bsk-[A-Za-z0-9_-]{8,}/g, 'sk-…')
    .replace(/\bcm_pro_[A-Za-z0-9_-]{8,}/g, 'cm_pro_…')
    .replace(/\b(Bearer|Basic|Digest|Token)\s+[^\s"']+/gi, '$1 …')
    // Numbers are limits/counts, not credentials — `max_tokens: 200000` and
    // `key limit exceeded` style diagnostics survive intact.
    .replace(CREDENTIAL_ASSIGNMENT_PATTERN, (match, prefix: string, quote: string, value: string) =>
      /^\d+$/.test(value) ? match : `${prefix}${quote}…${quote}`)
    .slice(0, MAX_ERROR_MESSAGE_LENGTH);
}

export function readObserverHealth(filePath: string = defaultHealthFilePath()): ObserverHealthState | null {
  try {
    if (!existsSync(filePath)) return null;
    const parsed: unknown = JSON.parse(readFileSync(filePath, 'utf-8'));
    if (typeof parsed !== 'object' || parsed === null) return null;
    return { ...EMPTY_STATE, ...(parsed as Partial<ObserverHealthState>) };
  } catch (error) {
    logger.warn('SESSION', 'Failed to read observer-health file', { filePath },
      error instanceof Error ? error : new Error(String(error)));
    return null;
  }
}

/**
 * True when a ledger write can change whether the SessionStart banner shows.
 * Every stored observation records a success, so invalidating on each write
 * would re-render every cached block continuously during active work.
 */
function bannerMayChange(prior: ObserverHealthState, next: ObserverHealthState): boolean {
  return isObserverUnhealthy(prior) !== isObserverUnhealthy(next)
    || JSON.stringify(prior.quotaCooldown) !== JSON.stringify(next.quotaCooldown);
}

function writeObserverHealth(state: ObserverHealthState, filePath: string, prior: ObserverHealthState): void {
  try {
    const dir = join(filePath, '..');
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true, mode: 0o700 });
    writeFileSync(filePath, JSON.stringify(state, null, 2), { encoding: 'utf-8', mode: 0o600 });
    // The outage banner rides inside the SessionStart block.
    if (bannerMayChange(prior, state)) emitContextInvalidation('all', 'observer-health');
  } catch (error) {
    logger.warn('SESSION', 'Failed to write observer-health file', { filePath },
      error instanceof Error ? error : new Error(String(error)));
  }
}

/** A holder that has not released within this window is presumed dead. */
const LEDGER_LOCK_STALE_MS = 5_000;
/** Give up waiting and update unlocked rather than lose the failure entirely. */
const LEDGER_LOCK_MAX_WAIT_MS = 2_000;
const LEDGER_LOCK_RETRY_MS = 10;

/**
 * Serialize the ledger's read-modify-write across processes. Every worker and
 * hook process shares one file, and lost increments would hold
 * consecutiveFailures below the threshold — suppressing the very warning this
 * module exists to raise.
 *
 * `wx` (O_CREAT|O_EXCL) makes the create itself the atomicity, matching
 * worker-spawn-gate.ts. The lock fails OPEN (unlocked update) when the
 * filesystem refuses it or the wait times out: a racy count beats no count.
 */
function withLedgerLock<T>(filePath: string, mutate: () => T): T {
  const lockPath = `${filePath}.lock`;
  const deadline = Date.now() + LEDGER_LOCK_MAX_WAIT_MS;
  let held = false;

  while (!held && Date.now() < deadline) {
    try {
      mkdirSync(dirname(lockPath), { recursive: true, mode: 0o700 });
      writeFileSync(lockPath, String(process.pid), { flag: 'wx', mode: 0o600 });
      held = true;
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (code !== 'EEXIST') {
        logger.warn('SESSION', 'Observer-health lock unavailable; updating unlocked', { lockPath, code },
          error instanceof Error ? error : new Error(String(error)));
        break;
      }
      let mtimeMs: number;
      try {
        mtimeMs = statSync(lockPath).mtimeMs;
      } catch {
        // Holder released between our failed create and the stat — retry.
        continue;
      }
      if (Date.now() - mtimeMs > LEDGER_LOCK_STALE_MS) {
        try {
          unlinkSync(lockPath);
        } catch {
          // A competing breaker won, or the fs refused the delete; the retry
          // loop re-evaluates either way.
        }
        continue;
      }
      sleepSync(LEDGER_LOCK_RETRY_MS);
    }
  }

  if (!held && Date.now() >= deadline) {
    logger.warn('SESSION', 'Timed out waiting for the observer-health lock; updating unlocked', { lockPath });
  }

  try {
    return mutate();
  } finally {
    if (held) {
      try {
        unlinkSync(lockPath);
      } catch {
        // Already broken as stale by a waiter — nothing to release.
      }
    }
  }
}

export function recordObserverFailure(
  provider: string,
  error: string | ObserverFailureDetail,
  filePath: string = defaultHealthFilePath(),
): void {
  const detail: ObserverFailureDetail = typeof error === 'string' ? { message: error } : error;
  const nextKind = detail.kind ?? null;
  withLedgerLock(filePath, () => {
    const prior = readObserverHealth(filePath) ?? EMPTY_STATE;
    const now = Date.now();
    writeObserverHealth({
      ...prior,
      consecutiveFailures: prior.consecutiveFailures + 1,
      // The streak's start belongs to the current failure kind (#5378): a quota pause
      // followed by auth refusals must not describe the auth warning with the quota
      // era's timestamp. A kind change (classified → unclassified included) restarts
      // the clock; only the streak itself waits for a success.
      failingSinceAt:
        prior.consecutiveFailures > 0 && (prior.lastErrorKind ?? null) === nextKind
          ? prior.failingSinceAt
          : now,
      lastErrorAt: now,
      lastErrorMessage: scrubErrorMessage(detail.message),
      lastErrorProvider: provider,
      // Always overwrite (never inherit from `prior`): a string-form failure
      // after a classified one must not keep the stale action/link/request id.
      lastErrorCode: detail.code ?? null,
      lastErrorKind: nextKind,
      lastErrorAction: detail.action ? scrubErrorMessage(detail.action) : null,
      lastErrorUrl: detail.url ?? null,
      lastErrorRequestId: detail.requestId ?? null,
    }, filePath, prior);
  });
}

export function recordObserverSuccess(filePath: string = defaultHealthFilePath()): void {
  withLedgerLock(filePath, () => {
    const prior = readObserverHealth(filePath) ?? EMPTY_STATE;
    writeObserverHealth({
      ...prior,
      consecutiveFailures: 0,
      failingSinceAt: null,
      lastSuccessAt: Date.now(),
    }, filePath, prior);
  });
}

/**
 * Mirror an armed quota breaker into the health ledger. Does not increment
 * consecutiveFailures — a cooldown is an intentional pause, not a failure.
 */
export function recordObserverQuotaCooldown(
  cooldown: ObserverQuotaCooldown,
  filePath: string = defaultHealthFilePath(),
): void {
  withLedgerLock(filePath, () => {
    const prior = readObserverHealth(filePath) ?? EMPTY_STATE;
    writeObserverHealth({
      ...prior,
      quotaCooldown: {
        active: true,
        provider: cooldown.provider,
        ...(cooldown.profile ? { profile: cooldown.profile } : {}),
        armedAt: cooldown.armedAt,
        until: cooldown.until,
        ...(cooldown.window ? { window: cooldown.window } : {}),
        ...(cooldown.message ? { message: scrubErrorMessage(cooldown.message) } : {}),
        ...(cooldown.servingProvider ? { servingProvider: cooldown.servingProvider } : {}),
        ...(cooldown.auth ? { auth: cooldown.auth } : {}),
        ...(cooldown.reason ? { reason: cooldown.reason } : {}),
        ...(cooldown.notice ? { notice: cooldown.notice } : {}),
      },
    }, filePath, prior);
  });
}

/** Clear the cooldown field after the breaker is released. */
export function clearObserverQuotaCooldown(
  filePath: string = defaultHealthFilePath(),
): void {
  withLedgerLock(filePath, () => {
    const prior = readObserverHealth(filePath);
    if (!prior || prior.quotaCooldown === null) return;
    writeObserverHealth({ ...prior, quotaCooldown: null }, filePath, prior);
  });
}

export function isObserverUnhealthy(state: ObserverHealthState | null): state is ObserverHealthState {
  // The threshold lets a blip self-heal before it warns. A refused credential
  // is not a blip — the provider said so — and the cooldown armed with it
  // allows no second attempt for a while, so waiting for the threshold would
  // hide the one remedy (a new key) for over an hour. A setup failure is the
  // same: it fails every request until the user acts, and its gate re-checks
  // only every few minutes.
  return state !== null
    && (state.consecutiveFailures >= OBSERVER_UNHEALTHY_FAILURE_THRESHOLD || isAuthFailure(state) || isSetupFailure(state))
    && (state.lastErrorAt ?? 0) > (state.lastSuccessAt ?? 0);
}

/** "3 minutes" / "about 2 hours" / "about 3 days" for outage durations. */
export function describeDuration(ms: number): string {
  const minutes = Math.max(1, Math.round(ms / 60_000));
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'}`;
  const hours = Math.round(minutes / 60);
  if (hours < 48) return `about ${hours} hour${hours === 1 ? '' : 's'}`;
  return `about ${Math.round(hours / 24)} days`;
}

/**
 * Where the one-click restart lives: the same base the viewer is printed at, so
 * it stays reachable when the worker runs behind a port-forward
 * (`CLAUDE_MEM_PUBLIC_URL`). Read through hook-settings rather than
 * worker-utils: this module is imported by hooks as well as the worker, and
 * must not drag in the supervisor, telemetry and process-management tree just
 * to format a URL.
 */
export function workerRestartUrl(): string {
  const settings = loadFromFileOnce();
  return `${viewerBaseUrl(settings.CLAUDE_MEM_WORKER_PORT, settings.CLAUDE_MEM_PUBLIC_URL)}/restart`;
}

/**
 * The block prepended to session-start context when unhealthy. Read by both
 * the user and the agent, so it stays calm and plain-spoken — but the agent
 * must still relay the outage (and the remedy embedded in the provider's
 * error message) to the user immediately.
 *
 * A restart clears nearly every observer outage (a wedged or SIGKILL'd provider
 * subprocess), so the remedy leads with one — as a link the user clicks, not as
 * something claude-mem fires on its own. Restarting the worker from inside the
 * worker means guarding the automation against itself (once per outage? per
 * flap? what about two failures racing?), and every one of those guards is a
 * bound on a loop that only exists because the restart was automatic. A human
 * pressing the button is the bound.
 */
/**
 * True when the current outage is a spent provider allowance. Reads the
 * classified `kind` recorded with the failure; the quota-as-prose path records
 * the same kind so both outage shapes are covered.
 */
export function isQuotaFailure(state: ObserverHealthState): boolean {
  return state.lastErrorKind === 'quota_exhausted';
}

/**
 * True when the current record is claude-mem's own precautionary stop
 * (RateLimitStore's `quota_guard`): usage crossed a reserve threshold or the
 * reset buffer while the provider was still accepting requests. Nothing is
 * exhausted that we know of, so the banner says "paused", not "used up".
 */
export function isQuotaGuardPause(state: ObserverHealthState): boolean {
  return state.lastErrorKind === 'quota_guard';
}

/**
 * The one message every quota abort used to be booked under, guard and
 * refusal alike. Legacy ledger records, and quota aborts that carry no kind,
 * still use it. Such a record cannot say whether anything was exhausted, so
 * the banner must not claim it was.
 */
export const AMBIGUOUS_QUOTA_MESSAGE = 'Provider reported the inference allowance exhausted';

/** True when the record is a quota failure booked without the guard's decision. */
export function isAmbiguousQuotaRecord(state: ObserverHealthState): boolean {
  return isQuotaFailure(state) && state.lastErrorMessage === AMBIGUOUS_QUOTA_MESSAGE;
}

/**
 * lastErrorCode of a signed-out Claude observer whose spawn found no login it
 * could use (#6319): claude-mem could not read one, so the CLI's own "/login"
 * advice may not apply. Booked by GeneratorRunner, worded below.
 */
export const CLAUDE_LOGIN_UNREADABLE_CODE = 'claude_login_unreadable';

/** True when the current outage is the provider refusing the observer's credential. */
export function isAuthFailure(state: ObserverHealthState): boolean {
  return state.lastErrorKind === 'auth_invalid';
}

/**
 * True when the current outage is setup the user has to fix: a missing CLI or
 * login, a model or effort the provider does not serve, a CLI too old for it.
 */
export function isSetupFailure(state: ObserverHealthState): boolean {
  return state.lastErrorKind === 'setup_required';
}

/**
 * How old a quota failure has to be before the banner stops asserting it as a
 * present fact.
 *
 * The number is `QUOTA_EXHAUSTED_RECHECK_COOLDOWN_MS` from `quota-cooldown.ts`,
 * copied rather than imported because that module imports this one. The test
 * suite asserts the two agree, so the copy cannot drift.
 *
 * Reusing that window rather than inventing a "provider reset interval" is the
 * point: it is already this codebase's answer to "long enough that a reset (or
 * a plan upgrade) is picked up". Once the breaker itself would let a probe
 * through, a recorded failure has stopped being evidence of a present outage —
 * it is the last thing we know, not the current state.
 */
export const OBSERVER_QUOTA_FAILURE_STALE_AFTER_MS = 30 * 60_000;

/** True once the recorded failure is at least one recheck window old. */
function hasOutlivedRecheckWindow(state: ObserverHealthState, nowMs: number): boolean {
  const lastErrorAt = state.lastErrorAt;
  // `>=`, not `>`: `isObserverQuotaCooldownActive` calls the cooldown expired
  // at `until > nowMs`, so at exactly the recheck interval the breaker has
  // already released. A strict `>` left one instant where the breaker was
  // open and the banner still called the outage current.
  return lastErrorAt !== null && nowMs - lastErrorAt >= OBSERVER_QUOTA_FAILURE_STALE_AFTER_MS;
}

/**
 * True when a quota outage is old enough that it may well be over.
 *
 * `observer-health.json` only heals as a side effect of the next SUCCESSFUL
 * generation, and that cannot happen until traffic arrives — which is after
 * SessionStart has already read the file. So the first session following any
 * recovered outage is guaranteed to read a stale ledger, however long ago the
 * allowance reset (#4083: a 63-hour-old error rendered as a live outage while
 * the worker stored observations four minutes later in the same session).
 *
 * Only failures that clear on their own age out: this one, the guard's
 * precautionary pause (isQuotaGuardPause, released by the same recheck window)
 * and a deadline expiry (isDeadlineFailureStale). A bad key or a missing base
 * URL stays true until someone fixes it, so its banner should keep saying so.
 */
export function isQuotaFailureStale(
  state: ObserverHealthState,
  nowMs: number = Date.now(),
): boolean {
  return (isQuotaFailure(state) || isQuotaGuardPause(state)) && hasOutlivedRecheckWindow(state, nowMs);
}

/**
 * True when a deadline outage — requests running past CLAUDE_MEM_LLM_TIMEOUT_MS
 * with nothing stored — is old enough that it may well be over.
 *
 * The #4083 trap again: a slow or stalled backend recovers on its own, but the
 * ledger only heals on the next save, which comes after SessionStart has read
 * it. The window is the quota one: once nothing has re-tested the backend for
 * that long, the expiry is the last thing we know, not the current state; if it
 * is still slow, the next expiry restores the full warning. The code is
 * provider-errors' DEADLINE_EXCEEDED_CODE, compared as a literal like
 * 'model_unavailable' below so this module stays free of worker imports. Any
 * other transient failure never reaches the ledger.
 */
export function isDeadlineFailureStale(
  state: ObserverHealthState,
  nowMs: number = Date.now(),
): boolean {
  return state.lastErrorCode === 'deadline_exceeded' && hasOutlivedRecheckWindow(state, nowMs);
}

/**
 * True while the persisted cooldown window is still in the future. `until`
 * wins over the stored `active` flag so an expired ledger cannot latch the
 * banner (the #3902 failure mode, inverted).
 */
export function isObserverQuotaCooldownActive(
  state: ObserverHealthState | null,
  nowMs: number = Date.now(),
): state is ObserverHealthState {
  const cooldown = state?.quotaCooldown;
  return cooldown != null
    && typeof cooldown.until === 'number'
    && cooldown.until > nowMs;
}

const QUOTA_PAUSE_MODEL_LINE = "(Assistant: at the start of your first reply, tell the user in one sentence that claude-mem has paused saving memories and why. Don't restart the worker or suggest it.)";

const CLAUDE_LIMIT_NAMES: Record<string, string> = {
  five_hour: '5-hour Claude limit',
  seven_day: 'weekly Claude limit',
  seven_day_opus: 'weekly Opus limit',
  seven_day_sonnet: 'weekly Sonnet limit',
  seven_day_overage_included: 'weekly Fable limit',
  overage: 'Claude extra usage',
};

/**
 * The zone notice times are shown in: TZ as it reads right now, else the
 * system zone. Passing it to Intl explicitly means a TZ set after startup is
 * honored even where the runtime cached the zone it started with (CI runners
 * are UTC). An unknown TZ falls back to the system zone, as Date itself does.
 */
function noticeTimeZone(): string | undefined {
  const zone = process.env.TZ?.trim();
  if (!zone) return undefined;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: zone });
    return zone;
  } catch {
    return undefined;
  }
}

/** Round upward so the displayed minute never promises a retry before admission. */
function quotaRetryTime(timestamp: number, nowMs: number): string {
  const timeZone = noticeTimeZone();
  const retry = new Date(Math.ceil(timestamp / 60_000) * 60_000);
  const day = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' });
  const today = day.format(retry) === day.format(new Date(nowMs));
  return new Intl.DateTimeFormat('en-US', {
    timeZone,
    ...(today ? {} : { weekday: 'short' as const }),
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(retry).replace(',', '');
}

function quotaHoldReason(
  hold: ObserverQuotaNoticeHold,
  nowMs: number,
  paused: boolean = false,
  backupDetail: boolean = false,
): string {
  const reason = hold.reason;
  const name = relayedProviderText(hold.displayName);
  if (!reason) return `${name} is on hold`;
  switch (reason.kind) {
    case 'unknown':
      return `${name} is on hold`;
    case 'limit_guard': {
      const limit = CLAUDE_LIMIT_NAMES[reason.window] ?? 'Claude allowance';
      const usage = `you've used ${reason.usagePercent}% of your ${limit}`;
      return backupDetail ? usage
        : `${usage} (${paused ? 'it' : 'claude-mem'} stops at ${reason.thresholdPercent}% to leave the rest for you)`;
    }
    case 'reset_buffer_guard':
      return `you've used ${reason.usagePercent}% of your 5-hour Claude limit and it resets at ${quotaRetryTime(reason.resetsAt, nowMs)} (claude-mem pauses in the last 15 minutes to leave the rest for you)`;
    case 'used_up':
      return `your ${CLAUDE_LIMIT_NAMES[reason.window ?? ''] ?? 'Claude allowance'} is used up`;
    case 'api_key_limit':
      return 'your Anthropic API key has hit its credit or usage limit';
    case 'out_of_quota':
      return `${name} says you're out of quota`;
    case 'unavailable':
      return `${name} isn't available`;
    case 'busy':
      return `${name} is busy (rate limited or over capacity)`;
  }
}

/** Old ledgers identify clients, but cannot establish roles or which Claude key was billed. */
function legacyQuotaProviderName(provider: string, auth?: string): string {
  switch (provider) {
    case 'claude': return auth === 'api-key' ? 'your Anthropic API key' : auth === 'subscription' ? 'your Claude plan' : 'Claude';
    case 'openrouter': return 'OpenRouter';
    case 'gemini': return 'Gemini';
    case 'codex': return 'Codex';
    case 'openai-compatible': return 'your OpenAI-compatible endpoint';
    case 'cmem-gateway': return 'cmem.ai';
    default: return 'your memory provider';
  }
}

/** SessionStart reports only a change to saving, using facts mirrored by dispatch. */
export function renderObserverQuotaCooldownNotice(
  state: ObserverHealthState,
  nowMs: number = Date.now(),
): string {
  if (!isObserverQuotaCooldownActive(state, nowMs)) return '';
  const cooldown = state.quotaCooldown!;
  const context = cooldown.notice;
  if (!context) {
    const held = legacyQuotaProviderName(cooldown.provider, cooldown.auth);
    const retry = cooldown.provider === 'claude' && cooldown.auth === 'subscription' ? 'Claude' : held;
    const time = quotaRetryTime(cooldown.until, nowMs);
    if (cooldown.servingProvider) {
      const serving = legacyQuotaProviderName(cooldown.servingProvider);
      return `ℹ️ claude-mem is using ${serving} to save memories while ${held} is on hold; it tries ${retry} again at ${time}.`;
    }
    return `⚠️ claude-mem has paused saving memories while ${held} is on hold. Activity during the pause isn't saved; saving starts again with new activity after ${time}, when it tries ${retry} again. You don't need to do anything, and restarting won't change it.\n${QUOTA_PAUSE_MODEL_LINE}`;
  }

  const backup = context.holds.find(hold => hold.role === 'backup' && hold.until > nowMs);
  const main = context.holds.find(hold => hold.role === 'main' && hold.until > nowMs);
  if (!main) {
    // A held backup says nothing is wrong only while another provider is
    // actually saving. When the backup was the one serving (cmem.ai switched
    // to Claude via CLAUDE_MEM_PRO_FALLBACK_AT, then Claude was held), saving
    // has stopped and the user must hear it.
    const serving = context.servingProvider;
    // A held Claude credential stops nothing while the other one is serving
    // (CLAUDE_MEM_QUOTA_FALLBACK_AUTH_METHOD).
    const servingIsHeld = context.holds.some(hold => hold.provider === serving && hold.until > nowMs
      && (!hold.auth || !context.servingAuth || hold.auth === context.servingAuth));
    if (!backup || (serving && !servingIsHeld)) return '';
    const backupTime = quotaRetryTime(backup.until, nowMs);
    return `⚠️ claude-mem has paused saving memories because ${quotaHoldReason(backup, nowMs, true)}. Activity during the pause isn't saved; saving starts again with new activity after ${backupTime}, when it tries ${relayedProviderText(backup.retryName)} again. You don't need to do anything, and restarting won't change it.\n${QUOTA_PAUSE_MODEL_LINE}`;
  }
  const time = quotaRetryTime(main.until, nowMs);
  const retryName = relayedProviderText(main.retryName);

  if (context.servingProvider) {
    const reason = quotaHoldReason(main, nowMs);
    if (main.provider === 'claude' && context.servingProvider === 'claude') {
      if (main.auth === 'api-key' && context.servingAuth === 'subscription') {
        return `ℹ️ claude-mem is using your Claude Code login to save memories because ${reason}. It switches back to the key on its own and tries it again at ${time}. Nothing to do.`;
      }
      if (main.auth === 'subscription' && context.servingAuth === 'api-key') {
        return `ℹ️ claude-mem is using your backup API key (ANTHROPIC_FALLBACK_API_KEY) to save memories because ${reason}. That key is billed per request. It switches back to your login on its own and tries it again at ${time}.`;
      }
    }
    const servingName = relayedProviderText(context.servingDisplayName ?? legacyQuotaProviderName(context.servingProvider));
    const optOut = context.defaultClaudeBackup && context.servingProvider === 'claude'
      ? ` (To stop using ${servingName} as a backup, set CLAUDE_MEM_QUOTA_FALLBACK_PROVIDER=off.)`
      : '';
    return `ℹ️ claude-mem is using ${servingName} to save memories because ${reason}. It switches back on its own and tries ${retryName} again at ${time}. Nothing to do.${optOut}`;
  }

  const reason = quotaHoldReason(main, nowMs, true);
  let notice: string;
  if (backup) {
    const backupReason = quotaHoldReason(backup, nowMs, true, true);
    const earliestTime = quotaRetryTime(Math.min(main.until, backup.until), nowMs);
    notice = `⚠️ claude-mem has paused saving memories because ${reason} and its backup, ${relayedProviderText(backup.displayName)}, is paused (${backupReason}). Activity during the pause isn't saved; saving starts again with new activity after ${earliestTime}, when it tries again. You don't need to do anything, and restarting won't change it.`;
  } else if (main.reason?.kind === 'busy') {
    notice = `⚠️ claude-mem has paused saving memories because ${reason}. Activity during the pause isn't saved; saving starts again with new activity after ${time}, when it tries ${retryName} again.`;
  } else {
    const chooseBackup = !context.backupProvider || context.backupProvider === context.mainProvider
      ? ' (To keep saving through limits, pick a backup in CLAUDE_MEM_QUOTA_FALLBACK_PROVIDER.)'
      : '';
    notice = `⚠️ claude-mem has paused saving memories because ${reason}. Activity during the pause isn't saved; saving starts again with new activity after ${time}, when it tries ${retryName} again. You don't need to do anything, and restarting won't change it.${chooseBackup}`;
  }
  return `${notice}\n${QUOTA_PAUSE_MODEL_LINE}`;
}

/**
 * The provider's words as the banner may relay them. They come from an error
 * body and reach model context, so each is one plain bounded line with its
 * credentials scrubbed, and a link only when approved (relayed-text.ts).
 */
function relayedProviderText(text: string | null | undefined): string {
  return text ? relayedLine(scrubErrorMessage(text)) : '';
}

/** The latest error plus the classified remedy, shared by every warning shape. */
function renderFailureDetailLines(state: ObserverHealthState, action: string | null): string[] {
  const link = relayedLink(state.lastErrorUrl);
  const requestId = relayedLine(state.lastErrorRequestId);
  return [
    `Latest error: ${relayedProviderText(state.lastErrorMessage) || 'unknown'}`,
    ...(action ? [`What to do: ${action}`] : []),
    ...(link ? [`Link: ${link}`] : []),
    ...(requestId ? [`Request id: ${requestId}`] : []),
  ];
}

/**
 * The note for a failure that clears on its own, once nothing has re-tested it
 * (isQuotaFailureStale, isDeadlineFailureStale). Same facts, stated as what
 * they are: the last thing we know, not the current state. No "nothing will be
 * remembered", because that would be a claim about right now that nothing has
 * checked; and no instruction to lead the reply with an outage report, because
 * the likeliest case by far is that the condition cleared and capture is
 * working.
 */
function renderLastKnownFailureNote(
  state: ObserverHealthState,
  nowMs: number,
  action: string | null,
  shape: { failedWith: string; remedyLabel: string; recovery: string },
): string {
  const provider = state.lastErrorProvider ?? 'unknown provider';
  const age = state.lastErrorAt ? describeDuration(nowMs - state.lastErrorAt) : 'an unknown time';
  const link = relayedLink(state.lastErrorUrl);
  return [
    `ℹ️ claude-mem: the memory observer last failed with ${shape.failedWith} on`,
    `${provider}, ${age} ago. Nothing has re-tested it since — the health ledger only`,
    'updates on the next successful save, which happens after this message is written.',
    '',
    `Last error: ${relayedProviderText(state.lastErrorMessage) || 'unknown'}`,
    ...(action ? [`${shape.remedyLabel}: ${action}`] : []),
    ...(link ? [`Link: ${link}`] : []),
    '',
    `${shape.recovery}, so memory capture may already be working. If it is`,
    'not, the next failed save brings the full warning back.',
    '',
    '(Assistant: do not open your reply with this. Mention it only if the user asks why',
    'something was not remembered, or if a later message reports a save failing.)',
  ].join('\n');
}

export function renderObserverHealthWarning(state: ObserverHealthState, nowMs: number = Date.now()): string {
  const since = state.failingSinceAt ?? state.lastErrorAt;
  const sinceText = since
    ? `for ${describeDuration(nowMs - since)} (since ${new Date(since).toISOString()})`
    : 'for an unknown amount of time';
  const provider = state.lastErrorProvider ?? 'unknown provider';
  const count = state.consecutiveFailures;
  const action = relayedProviderText(state.lastErrorAction) || null;

  if (isQuotaFailureStale(state, nowMs)) {
    // A guard pause, or a record that cannot tell the guard from a refusal,
    // is not evidence that anything was spent.
    const precautionary = isQuotaGuardPause(state) || isAmbiguousQuotaRecord(state);
    return renderLastKnownFailureNote(state, nowMs, action, precautionary
      ? {
        failedWith: 'a usage-related pause',
        remedyLabel: 'If it is still paused',
        recovery: 'Usage pauses release on their own',
      }
      : {
        failedWith: 'a spent allowance',
        remedyLabel: 'If it is still spent',
        recovery: 'Allowances reset on their own',
      });
  }
  if (isDeadlineFailureStale(state, nowMs)) {
    return renderLastKnownFailureNote(state, nowMs, action, {
      failedWith: 'requests running past their deadline',
      remedyLabel: 'If it is still slow',
      recovery: 'A slow backend usually recovers on its own',
    });
  }

  // claude-mem's own reserve guard stopped capture while the provider was
  // still accepting requests, or the record was booked without the guard's
  // decision and cannot tell the two apart. Either way nothing is known to be
  // exhausted: say "paused", relay the guard's own reason, point at the
  // provider's usage page, and offer no restart (a restart replenishes
  // nothing and the breaker it would release is the pause itself).
  if (isQuotaGuardPause(state) || isAmbiguousQuotaRecord(state)) {
    const guard = isQuotaGuardPause(state);
    return [
      '⚠️ Heads up: claude-mem memory capture is paused.',
      '',
      guard
        ? `Memory capture is paused to preserve your Claude allowance (${sinceText}).`
        : `The memory observer has a usage-related pause on ${provider} (${sinceText}).`,
      '',
      guard
        ? `Reason: ${relayedProviderText(state.lastErrorMessage) || 'Precautionary usage guard'}`
        : 'This record cannot tell a precautionary pause from a provider rejection.',
      '',
      'Existing memories remain available; new memory generation is paused.',
      `After the ${OBSERVER_QUOTA_FAILURE_STALE_AFTER_MS / 60_000}-minute cooldown, the next activity can trigger one retry.`,
      'Capture resumes when usage is below the guard thresholds and the provider accepts requests.',
      provider === 'claude'
        ? 'Check Claude Settings → Usage for the current usage and reset time.'
        : `Check ${provider} usage settings for the current allowance and reset time.`,
      '',
      'Restarting does not replenish allowance or clear the persisted cooldown.',
      '',
      '(Assistant: tell the user about this pause at the start of your first reply.',
      'Relay the reason accurately; do not call a precautionary pause provider exhaustion.',
      'Do NOT restart the worker or change providers to bypass the pause.)',
    ].join('\n');
  }

  // A spent allowance is the one outage a restart cannot clear. Nothing is
  // wedged; the account is out of allowance. Say that, and relay the
  // provider's own remedy.
  if (isQuotaFailure(state)) {
    return [
      "⚠️ Heads up: claude-mem can't save memories right now.",
      '',
      `The memory observer's allowance on ${provider} is used up (since ${sinceText.replace(/^for .*?\(since /, '').replace(/\)$/, '')}).`,
      '',
      ...renderFailureDetailLines(state, action),
      '',
      "Until the allowance resets or you add capacity, nothing from this session — or any",
      'other — will be remembered.',
      '',
      // Deliberately no restart link: nothing is broken to restart, and the
      // quota breaker is persisted, so a restart revives it rather than
      // clearing it.
      'Restarting will NOT help here: it does not replenish the allowance or clear the',
      'persisted cooldown — so please leave the worker alone.',
      ...(action ? [] : [
        'Switch the observer to another provider in ~/.claude-mem/settings.json if you need',
        'memory capture before the allowance resets.',
      ]),
      '',
      '(Assistant: tell the user about this outage at the very start of your first reply,',
      'quoting the error above. Do NOT restart the worker and do NOT suggest restarting it.)',
    ].join('\n');
  }

  // A retired or unknown model is the other outage a restart cannot clear:
  // every fresh generator asks for the same model and gets the same refusal.
  // Only changing the model fixes it, so relay that remedy, not a restart link.
  if (state.lastErrorCode === 'model_unavailable') {
    return [
      "⚠️ Heads up: claude-mem can't save memories right now.",
      '',
      `The memory observer (provider: ${provider}) has failed ${count} time${count === 1 ? '' : 's'} in a row ${sinceText}: its configured model is no longer available.`,
      '',
      ...renderFailureDetailLines(state, action),
      '',
      "Until the model is changed, nothing from this session — or any other — will be remembered.",
      '',
      'Restarting will NOT help here: after a restart the observer asks for the same model',
      'and gets the same refusal.',
      '',
      '(Assistant: tell the user about this outage at the very start of your first reply,',
      'quoting the error and the "What to do" line above. Do NOT suggest restarting the worker.)',
    ].join('\n');
  }

  // A refused credential cannot be cleared by a restart either: the provider
  // rejected the key (or the account), and nothing is wedged. Relay the
  // provider's remedy instead of offering a restart that changes nothing.
  if (isAuthFailure(state)) {
    // provider-errors' CODEX_AUTH_FROM_EXIT_TEXT_CODE: our reading of an exited
    // process's stderr, which can be wrong, not a refusal the provider sent.
    const readFromExitText = state.lastErrorCode === 'codex_auth_from_exit_text';
    const loginUnreadable = state.lastErrorCode === CLAUDE_LOGIN_UNREADABLE_CODE;
    return [
      "⚠️ Heads up: claude-mem can't save memories right now.",
      '',
      readFromExitText
        ? `The memory observer has been paused ${sinceText}: the ${provider} process exited with output that looks like a refused login.`
        : loginUnreadable
          ? `The memory observer has been signed out ${sinceText}: claude-mem could not read your Claude Code login.`
          : `The memory observer's credentials have been refused by ${provider} ${sinceText}.`,
      '',
      ...renderFailureDetailLines(state, action),
      '',
      "Until that's fixed, nothing from this session — or any other — will be remembered.",
      '',
      ...(readFromExitText ? [
        'This comes from the exited process\'s output, not a reply from the provider, so it may be wrong.',
        'Run `codex login status` to check. If the login is fine, the next captured event or an operator retry can trigger another attempt after the cooldown ends.',
      ] : loginUnreadable ? [
        'Restarting will NOT help here: the worker reads the same credential store again.',
      ] : [
        'Restarting will NOT help here: the provider refused the credentials, so nothing is broken to restart.',
      ]),
      ...(action || readFromExitText ? [] : [
        "Check the observer provider's API key in ~/.claude-mem/settings.json, or switch the",
        'observer to another provider there.',
      ]),
      '',
      '(Assistant: tell the user about this outage at the very start of your first reply,',
      'quoting the error above. Do NOT restart the worker and do NOT suggest restarting it.)',
    ].join('\n');
  }

  const lines = [
    "⚠️ Heads up: claude-mem can't save memories right now.",
    '',
    `The memory observer (provider: ${provider}) has failed ${count} time${count === 1 ? '' : 's'} in a row ${sinceText}.`,
    '',
    ...renderFailureDetailLines(state, action),
    '',
    "Until it's fixed, nothing from this session — or any other — will be remembered.",
    '',
    'Restarting the memory worker clears almost every outage. Do one of these:',
    `  Click to restart:  ${workerRestartUrl()}`,
    '  Or in a terminal:  npx claude-mem restart',
    '',
    'Still failing after the restart? Run: npx claude-mem doctor',
    // A classified error already says what to do; the generic settings.json
    // remedy is wrong for e.g. Pro users whose allowance ran out.
    ...(action ? [] : [
      "If doctor comes back clean, check the observer provider's API key, spend limit, and base",
      'URL in ~/.claude-mem/settings.json. The error above may include a management link.',
    ]),
    '',
    '(Assistant: tell the user about this outage at the very start of your first reply,',
    'quoting the error above, and give them the restart link — let them press it rather',
    'than restarting the worker yourself.)',
  ];
  return lines.join('\n');
}
