// SPDX-License-Identifier: Apache-2.0

import type { Job } from 'bullmq';
import { logger } from '../../utils/logger.js';
import { PostgresAuthRepository } from '../../storage/postgres/auth.js';
import type { PostgresPool } from '../../storage/postgres/pool.js';
import { DEFAULT_PROVIDER_GENERATE_TIMEOUT_MS, ProviderObservationGenerator } from '../generation/ProviderObservationGenerator.js';
import { reclaimStaleProcessingJobs } from '../generation/reclaimStaleProcessingJobs.js';
import type { ServerGenerationProvider } from '../generation/providers/shared/types.js';
import type { ServerGenerationJobPayload } from '../jobs/types.js';
import type { ActiveServerQueueManager } from './ActiveServerQueueManager.js';
import type {
  ServerBoundaryHealth,
  ServerGenerationWorkerManager,
} from './types.js';

// ActiveServerGenerationWorkerManager wires a BullMQ Worker (per the
// 'event' queue) to a ProviderObservationGenerator. Concurrency defaults to
// 1 per the plan (line 80–86) so retries observe a single inflight provider
// call per server. autorun:false / explicit run() is enforced by
// ServerJobQueue.start.
//
// This class is wired in only when both a queue manager AND a configured
// provider are present. create-server-service keeps the disabled
// adapter otherwise so the server can boot without provider credentials.

const STALE_LOCK_MULTIPLIER = 3;

export interface ActiveServerGenerationWorkerManagerOptions {
  pool: PostgresPool;
  queueManager: ActiveServerQueueManager;
  provider: ServerGenerationProvider;
  workerId?: string;
  // Test seam: replace the generator with a stub.
  generatorFactory?: (
    pool: PostgresPool,
    provider: ServerGenerationProvider,
    workerId: string,
  ) => ProviderObservationGenerator;
}

export class ActiveServerGenerationWorkerManager implements ServerGenerationWorkerManager {
  readonly kind = 'generation-worker-manager' as const;
  private started = false;
  private closed = false;
  private readonly generator: ProviderObservationGenerator;
  private readonly workerId: string;
  private staleSweepTimer: ReturnType<typeof setInterval> | null = null;
  private staleSweepInFlight: Promise<void> | null = null;

  constructor(private readonly options: ActiveServerGenerationWorkerManagerOptions) {
    this.workerId = options.workerId ?? `server-${process.pid}`;
    this.generator = options.generatorFactory
      ? options.generatorFactory(options.pool, options.provider, this.workerId)
      : new ProviderObservationGenerator({
          pool: options.pool,
          provider: options.provider,
          workerId: this.workerId,
        });
  }

  /**
   * Attach BullMQ Worker to the 'event' queue. Per BullMQ docs we use
   *   new Worker(queueName, processor, { concurrency, autorun })
   * via ServerJobQueue.start(...). Errors are surfaced through the queue
   * wrapper's worker.on('error', ...) listener.
   */
  start(): void {
    if (this.started) return;
    const dispatcher = async (job: Job<ServerGenerationJobPayload>) => {
      try {
        return await this.generator.process(job);
      } catch (error) {
        logger.warn('SYSTEM', 'observation generator failed', {
          jobId: job.id,
          kind: job.data.kind,
          error: error instanceof Error ? error.message : String(error),
        });
        throw error;
      }
    };
    this.options.queueManager.start('event', dispatcher);
    // Phase 6: wire the summary lane alongside the event lane. Concurrency
    // defaults to 1 per ServerJobQueue config (per the plan), and the same
    // ProviderObservationGenerator dispatches on job.data.source_type via the
    // outbox row reload inside lockOutbox+process.
    this.options.queueManager.start('summary', dispatcher);

    // Phase 12 — audit stalled events directly. Phase 11's audit chain now
    // covers the operator and provider lifecycle; stalled jobs come from
    // BullMQ runtime not the HTTP boundary, so we wire them in here. Best-
    // effort: a missing/unscoped audit MUST NOT crash the worker.
    for (const lane of ['event', 'summary'] as const) {
      try {
        const queue = this.options.queueManager.getQueue(lane);
        queue.observe({
          onStalled: (jobId) => {
            void this.auditStalledJob(jobId, lane);
          },
        });
      } catch (error) {
        logger.warn('SYSTEM', `failed to wire stalled observer for ${lane} lane`, {
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }

    this.startStaleSweep();
    this.started = true;
  }

  // A row is stale once its lock is several BullMQ lock durations old: by
  // then BullMQ has long since declared the job stalled, so no live worker
  // still holds it. Sweep once at boot (the case a crash leaves behind) and
  // then every lock duration.
  //
  // The threshold also never drops below one full provider call plus a lock
  // duration, so a live but slow provider.generate() can't be reclaimed even
  // if the lock duration is tuned down.
  private startStaleSweep(): void {
    const lockDurationMs = this.options.queueManager.getQueue('event').getLockDurationMs();
    const staleAfterMs = Math.max(
      lockDurationMs * STALE_LOCK_MULTIPLIER,
      DEFAULT_PROVIDER_GENERATE_TIMEOUT_MS + lockDurationMs,
    );
    const sweep = () => {
      // A slow sweep must not overlap the next tick. Retain ownership through
      // shutdown so its final outbox transition precedes pool closure.
      if (this.staleSweepInFlight || this.closed) return;
      this.staleSweepInFlight = this.sweepStaleJobs(staleAfterMs).finally(() => {
        this.staleSweepInFlight = null;
      });
    };
    sweep();
    this.staleSweepTimer = setInterval(sweep, lockDurationMs);
    this.staleSweepTimer.unref?.();
  }

  private async sweepStaleJobs(staleAfterMs: number): Promise<void> {
    try {
      await reclaimStaleProcessingJobs({
        pool: this.options.pool,
        staleAfterMs,
        resolveQueue: (lane) => this.options.queueManager.getQueue(lane),
      });
    } catch (error) {
      logger.warn('SYSTEM', 'stale generation job sweep failed', {
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // Phase 12 — write a `generation_job.stalled` audit row. We look up the
  // outbox row by BullMQ jobId (== bullmq_job_id column) so team/project
  // scope is correct on the audit row even when the original API key
  // metadata is unavailable (BullMQ retries can outlive a session).
  private async auditStalledJob(bullmqJobId: string, lane: 'event' | 'summary'): Promise<void> {
    try {
      await this.writeStalledJobAuditRow(bullmqJobId, lane);
    } catch (error) {
      logger.warn('SYSTEM', 'failed to audit stalled generation_job', {
        bullmqJobId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // Look up the outbox row by BullMQ jobId and, when found, write the
  // `generation_job.stalled` audit row scoped to that row's team/project.
  private async writeStalledJobAuditRow(
    bullmqJobId: string,
    lane: 'event' | 'summary',
  ): Promise<void> {
    const result = await this.options.pool.query<{
      id: string;
      team_id: string | null;
      project_id: string | null;
    }>(
      'SELECT id, team_id, project_id FROM observation_generation_jobs WHERE bullmq_job_id = $1 LIMIT 1',
      [bullmqJobId],
    );
    const row = result.rows[0];
    if (!row) return;
    const repo = new PostgresAuthRepository(this.options.pool);
    await repo.createAuditLog({
      teamId: row.team_id,
      projectId: row.project_id,
      actorId: null,
      apiKeyId: null,
      action: 'generation_job.stalled',
      resourceType: 'observation_generation_job',
      resourceId: row.id,
      details: { lane, bullmqJobId },
    });
  }

  getHealth(): ServerBoundaryHealth {
    if (this.closed) {
      return { status: 'errored', reason: 'generation-worker-manager closed' };
    }
    return {
      status: this.started ? 'active' : 'disabled',
      reason: this.started
        ? 'BullMQ Worker attached to event queue with ProviderObservationGenerator'
        : 'wired but not started',
      details: {
        provider: this.options.provider.providerLabel,
        workerId: this.workerId,
      },
    };
  }

  async close(): Promise<void> {
    this.closed = true;
    if (this.staleSweepTimer) clearInterval(this.staleSweepTimer);
    await this.staleSweepInFlight;
    // The underlying Worker is owned by ServerJobQueue.close() (driven by
    // the queue manager). We do not double-close here; the queue manager's
    // close cascade handles it.
  }
}
