// SPDX-License-Identifier: Apache-2.0

import { ModeManager } from '../../../../services/domain/ModeManager.js';
import type { ModeConfig, ObservationType } from '../../../../services/domain/types.js';
import { stripTags } from '../../../../utils/tag-stripping.js';
import { REDACTION_MARKER_HINT, hasRedactionMarker } from '../../../../utils/redaction.js';
import { logger } from '../../../../utils/logger.js';
import type { PostgresAgentEvent } from '../../../../storage/postgres/agent-events.js';
import type { ServerGenerationContext } from './types.js';
import { retainTextHeadTail } from '../../../../shared/text-truncation.js';

// Fallback list mirrors the default observation types used by claude-mem
// modes. The server-beta prompt does not strictly need a loaded mode file —
// the parser accepts any of these as the <type> value — so when no mode is
// loaded (tests, fresh installs) we synthesize a minimal type list rather
// than throwing.
const FALLBACK_OBSERVATION_TYPES: ReadonlyArray<Pick<ObservationType, 'id'>> = [
  { id: 'discovery' },
  { id: 'progress' },
  { id: 'blocker' },
  { id: 'decision' },
];

// Build a single-shot generation prompt from a list of AgentEvent records
// plus project/session metadata. Output: a user prompt asking the provider
// to return one or more <observation> XML blocks (or a self-closing
// <skip_summary /> if the batch should be skipped). This is intentionally a single-turn request
// — server-beta does NOT use the worker's multi-turn SDK conversation
// model. parseAgentXml(...) accepts the response unchanged.
//
// Privacy: every event payload field passes through `stripTags` (which
// removes <private>, <claude-mem-context>, <system-reminder>, etc.) before
// being included in the prompt. Privacy enforcement here is belt-and-suspenders
// — `processGeneratedResponse` also discards observations that are entirely
// derived from privately-tagged inputs.

export interface BuildServerPromptResult {
  readonly prompt: string;
  readonly hadPrivateContent: boolean;
  readonly skippedAll: boolean;
  /** No events were loaded at all — distinct from "loaded, then scrubbed away". */
  readonly noEvents: boolean;
}

const MAX_PAYLOAD_CHARS = 16 * 1024;

export function buildServerGenerationPrompt(
  context: ServerGenerationContext,
  options: { mode?: ModeConfig } = {},
): BuildServerPromptResult {
  const mode = options.mode ?? loadActiveModeOrFallback();

  let hadPrivateContent = false;
  let allEventsScrubbedToEmpty = true;
  const eventBlocks: string[] = [];

  for (const event of context.events) {
    const block = buildEventBlock(event);
    if (block.hadPrivate) {
      hadPrivateContent = true;
    }
    if (block.body.length > 0) {
      allEventsScrubbedToEmpty = false;
      eventBlocks.push(block.body);
    }
  }

  const skippedAll = context.events.length > 0 && allEventsScrubbedToEmpty;
  // An EMPTY input is not a privacy strip, and saying so in the prompt handed
  // the model the exact pretext the instruction below names — it answered
  // <skip_summary /> and the job completed with nothing. Kept separate so the
  // caller can refuse the call instead of buying that answer.
  const noEvents = context.events.length === 0;

  // Only the folder label helps the model; the project, team, session and job
  // ids are opaque UUIDs it never needs, and nothing reads them back from the
  // response (the job is identified by the BullMQ payload and the outbox row).
  const projectTag = context.project.projectName
    ? [`  <project_name>${escapeXml(context.project.projectName)}</project_name>`]
    : [];

  const observationOutputSchema = buildObservationOutputSchema(mode);

  // Summary jobs are a different task from event jobs, and the persistence path
  // for them (processGeneratedResponse -> parsed.summary) only understands a
  // <summary> block. Asking for <observation> here yields a response the summary
  // path silently discards, so branch the instruction on the job's source type.
  const isSessionSummary = context.job.sourceType === 'session_summary';

  const summaryInstruction = [
    'You are reviewing a complete agent session. Return a single',
    '<summary>...</summary> XML block describing the arc of the session. If the',
    'session contains nothing worth recording (e.g., everything was scrubbed by',
    'privacy filters or the activity was trivial), return a single self-closing',
    '<skip_summary /> tag and nothing else. Do not include any prose outside the XML.',
    '',
    'Schema for the <summary> block (at least one field must contain content):',
    '<summary>',
    '  <request>what the user asked for</request>',
    '  <investigated>what was explored, and how</investigated>',
    '  <learned>durable findings worth remembering later</learned>',
    '  <completed>what was actually done</completed>',
    '  <next_steps>what is left open</next_steps>',
    '  <notes>anything else worth keeping</notes>',
    '</summary>',
  ];

  const observationInstruction = [
    'You are observing an agent at work. Return one or more',
    '<observation>...</observation> XML blocks summarizing durable, useful',
    'discoveries from the events above. If the events contain nothing worth',
    'recording (e.g., everything was scrubbed by privacy filters or the',
    'activity was trivial), return a single self-closing <skip_summary />',
    'tag and nothing else. Do not include any prose outside the XML.',
    '',
    'Schema for each <observation> block:',
    observationOutputSchema,
  ];

  // The instructions stay after the events. Placed first (so every request
  // would share a cacheable prefix), DeepSeek V4.1 Flash wrote ~25% fewer
  // observations on the same 40 events and skipped 12 of them instead of 2.
  const prompt = [
    '<server_beta_observation_request>',
    ...projectTag,
    '  <agent_events>',
    eventBlocks.length > 0
      ? eventBlocks.join('\n')
      : noEvents
        ? '    <!-- no agent events were loaded for this session -->'
        : '    <!-- empty after privacy stripping -->',
    '  </agent_events>',
    '</server_beta_observation_request>',
    '',
    ...(isSessionSummary ? summaryInstruction : observationInstruction),
    ...(eventBlocks.some(hasRedactionMarker) ? ['', REDACTION_MARKER_HINT] : []),
  ].join('\n');

  return { prompt, hadPrivateContent, skippedAll, noEvents };
}

interface EventBlockResult {
  body: string;
  hadPrivate: boolean;
}

function buildEventBlock(event: PostgresAgentEvent): EventBlockResult {
  // Compact JSON: indentation is input the model doesn't need.
  const rawPayload =
    typeof event.payload === 'string' ? event.payload : JSON.stringify(event.payload ?? {});

  const stripResult = stripTags(rawPayload);
  const hadPrivate = (stripResult.counts.private ?? 0) > 0;
  const truncatedPayload = stripResult.stripped.length > MAX_PAYLOAD_CHARS
    // Never split a surrogate pair: a lone surrogate makes the provider reject the request.
    ? retainTextHeadTail(stripResult.stripped, MAX_PAYLOAD_CHARS, 0).head + '\n[...truncated]'
    : stripResult.stripped;

  if (truncatedPayload.trim().length === 0) {
    return { body: '', hadPrivate };
  }

  return {
    body: [
      '    <agent_event>',
      `      <event_type>${escapeXml(event.eventType)}</event_type>`,
      `      <occurred_at>${new Date(event.occurredAtEpoch).toISOString()}</occurred_at>`,
      '      <payload>',
      escapeXmlText(truncatedPayload),
      '      </payload>',
      '    </agent_event>',
    ].join('\n'),
    hadPrivate,
  };
}

/**
 * Bytes this event contributes to the prompt.
 *
 * Measured on the block the prompt actually carries, not estimated from the raw
 * row: the payload is pretty-printed, privacy-stripped, truncated, XML-escaped
 * and wrapped in metadata tags above, and a caller that budgets the input has to
 * agree with all of it. Deriving the number a second time is what let the two
 * drift apart in the first place.
 *
 * Returns 0 for an event whose block is dropped, so it costs no budget either.
 */
export function eventBlockBytes(event: PostgresAgentEvent): number {
  const { body } = buildEventBlock(event);
  if (body.length === 0) return 0;
  // + 1 for the '\n' that joins this block to the next one
  return Buffer.byteLength(body, 'utf8') + 1;
}

function loadActiveModeOrFallback(): ModeConfig | { observation_types: ReadonlyArray<Pick<ObservationType, 'id'>> } {
  try {
    return ModeManager.getInstance().getActiveMode();
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    logger.warn('SDK', 'Failed to load active mode; using fallback observation types', {
      fallbackTypes: FALLBACK_OBSERVATION_TYPES.map(t => t.id),
    }, err);
    return { observation_types: FALLBACK_OBSERVATION_TYPES } as unknown as ModeConfig;
  }
}

function buildObservationOutputSchema(mode: ModeConfig | { observation_types: ReadonlyArray<Pick<ObservationType, 'id'>> }): string {
  const types = mode.observation_types.map(t => t.id).join(' | ');
  return [
    '<observation>',
    `  <type>[ ${types} ]</type>`,
    '  <title>...</title>',
    '  <subtitle>...</subtitle>',
    '  <facts><fact>...</fact></facts>',
    '  <narrative>...</narrative>',
    '  <concepts><concept>...</concept></concepts>',
    '  <files_read><file>...</file></files_read>',
    '  <files_modified><file>...</file></files_modified>',
    '</observation>',
  ].join('\n');
}

/**
 * Escaping for XML character data: only `&`, `<` and `>` need it. Quotes do
 * not, and turning every `"` of a JSON payload into `&quot;` cost ~14% of the
 * input tokens of a generation call.
 */
function escapeXmlText(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
